# coding=utf-8

import os
import time
import argparse
import multiloss_transformer.way2del.modeling as modeling
import optimization
# from data_helper import *
import tensorflow as tf
from data_pro_new import *
from multiloss_transformer.way2del.mx_util import *
import config
from tensorflow.python.ops import variable_scope

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description='semantic representation')
config.add_data_args(parser)
config.add_net_args(parser)
config.add_train_args(parser)
args = parser.parse_args()
word2idx = load_vocab(args.vocab_file)  # 修改
# print(args)
# ----------------------------- define parameter end ---------------------------

#ori_quests, cand_quests, zsd_quests = load_train_data(
#    args.train_file, word2idx, args.num_unroll_steps, 10, mode=args.format)

test_infos = get_test_info(args.test_file, word2idx, args.num_unroll_steps, mode=args.format)
test_recall_infos = get_recall_info(args.recall_file, word2idx, test_infos, args.num_unroll_steps, mode=args.format)

# ----------------------------- define a logger --------------------------------
logger = logging.getLogger("execute")
logger.setLevel(logging.INFO)

fh = logging.FileHandler(args.log_path, mode="w")
fh.setLevel(logging.INFO)

fmt = "%(asctime)-15s %(levelname)s %(filename)s %(lineno)d %(process)d %(message)s"
datefmt = "%a %d %b %Y %H:%M:%S"
formatter = logging.Formatter(fmt, datefmt)

fh.setFormatter(formatter)
logger.addHandler(fh)
# ----------------------------- define a logger end ----------------------------

# ------------------------------------load data --------------------------------
tf.logging.info(args)

max_seq_length = args.num_unroll_steps
ori_input_quests_ph = tf.placeholder(
    tf.int32, shape=[None, max_seq_length], name='ori_input_quests')
pos_input_quests_ph = tf.placeholder(
    tf.int32, shape=[None, max_seq_length], name='pos_input_quests')
neg_input_quests_ph = tf.placeholder(
    tf.int32, shape=[None, max_seq_length], name='neg_input_quests')
ori_input_mask_ph = tf.placeholder(
    tf.int32, shape=(None, max_seq_length), name='ori_input_mask_ph')
pos_input_mask_ph = tf.placeholder(
    tf.int32, shape=(None, max_seq_length), name='pos_input_mask_ph')
neg_input_mask_ph = tf.placeholder(
    tf.int32, shape=(None, max_seq_length), name='neg_input_mask_ph')
ori_segment_ids_ph = tf.placeholder(
    tf.int32, shape=(None, max_seq_length), name='ori_segment_ids_ph')
pos_segment_ids_ph = tf.placeholder(
    tf.int32, shape=(None, max_seq_length), name='pos_segment_ids_ph')
neg_segment_ids_ph = tf.placeholder(
    tf.int32, shape=(None, max_seq_length), name='neg_segment_ids_ph')
is_training = tf.placeholder(tf.bool, name='is_training')

bert_config = modeling.BertConfig.from_json_file(args.BERT_cfg)  # 修改
init_checkpoint = args.pre_model  # 修改

# ori representatopn
with variable_scope.variable_scope(
        variable_scope.get_variable_scope(), reuse=tf.AUTO_REUSE):
    ori_feature = modeling.BertModel(
        config=bert_config,
        is_training=is_training,
        input_ids=ori_input_quests_ph,
        input_mask=ori_input_mask_ph,
        token_type_ids=ori_segment_ids_ph).get_pooled_output()
with variable_scope.variable_scope(
        variable_scope.get_variable_scope(), reuse=tf.AUTO_REUSE):
    # pos representatopn
    pos_feature = modeling.BertModel(
        config=bert_config,
        is_training=is_training,
        input_ids=pos_input_quests_ph,
        input_mask=pos_input_mask_ph,
        token_type_ids=pos_segment_ids_ph).get_pooled_output()
with variable_scope.variable_scope(
        variable_scope.get_variable_scope(), reuse=tf.AUTO_REUSE):
    # neg representatopn
    neg_feature = modeling.BertModel(
        config=bert_config,
        is_training=is_training,
        input_ids=neg_input_quests_ph,
        input_mask=neg_input_mask_ph,
        token_type_ids=neg_segment_ids_ph).get_pooled_output()

loss, accuracy = cal_loss(
    feature2cos_sim(ori_feature, pos_feature),
    feature2cos_sim(ori_feature, neg_feature))

num_train_steps = 121
warmup_proportion = 0.1
num_warmup_steps = 2131
tf.logging.info('num_train_steps: {0}, num_warmup_steps: {1}'.format(
    num_train_steps, num_warmup_steps
))
train_op = optimization.create_optimizer(
    loss, 5e-5, num_train_steps, num_warmup_steps, False)

# init from pretrained file
tvars = tf.trainable_variables()
initialized_variable_names = None
if init_checkpoint:
    tf.logging.info('init model from {0}'.format(init_checkpoint))
    (assignment_map, initialized_variable_names
     ) = modeling.get_assignment_map_from_checkpoint(tvars, init_checkpoint)

    tf.train.init_from_checkpoint(init_checkpoint, assignment_map)

tf.logging.info("**** Trainable Variables ****")
for var in tvars:
    init_string = ""
    if init_checkpoint and var.name in initialized_variable_names:
        init_string = ", *INIT_FROM_CKPT*"
    tf.logging.info("  name = %s, shape = %s%s", var.name, var.shape,
                    init_string)

gpu_options = tf.GPUOptions(allow_growth=True)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
init = tf.global_variables_initializer()
sess.run(init)

model_saver = tf.train.Saver(max_to_keep=50)


def get_feed_dict(ori_train, pos_train, neg_train, is_train):
    ori_input_mask = (ori_train > 0).astype('int32')
    pos_input_mask = (pos_train > 0).astype('int32')
    neg_input_mask = (neg_train > 0).astype('int32')
    ori_segment_ids = np.zeros_like(ori_train, dtype='int32')
    pos_segment_ids = np.zeros_like(pos_train, dtype='int32')
    neg_segment_ids = np.zeros_like(neg_train, dtype='int32')
    feed_dict = {
        ori_input_quests_ph: ori_train,
        ori_input_mask_ph: ori_input_mask,
        ori_segment_ids_ph: ori_segment_ids,
        pos_input_quests_ph: pos_train,
        pos_input_mask_ph: pos_input_mask,
        pos_segment_ids_ph: pos_segment_ids,
        neg_input_quests_ph: neg_train,
        neg_input_mask_ph: neg_input_mask,
        neg_segment_ids_ph: neg_segment_ids,
        is_training: is_train,
    }
    return feed_dict


def get_feed_dict_test(ori_train, is_train=False):
    ori_input_mask = (ori_train > 0).astype('int32')
    ori_segment_ids = np.zeros_like(ori_train, dtype='int32')
    feed_dict = {
        ori_input_quests_ph: ori_train,
        ori_input_mask_ph: ori_input_mask,
        ori_segment_ids_ph: ori_segment_ids,
        is_training: is_train,
    }
    return feed_dict


def deal_cmp_line_sentence(a, b):
    a = a.lower().replace("\"", "")
    b = b.lower().replace("\"", "")
    a_s = [w for w in a.split(" ")]
    b_s = [w for w in b.strip("{").strip("}").split(",")]
    ma = ['', '', '', '', '']
    mb = ['', '', '', '', '']
    for w in a_s:
        if not '=' in w:
            ma[0] = w
            break
        k, v = w.split("=")
        v = v.replace("default", "")
        v = v.replace("@", "")
        if k == "action":
            ma[0] = v
        if k == "target":
            ma[1] = v
        if k == "target.params1":
            ma[2] = v
        if k == "target.params2":
            ma[3] = v
        if k == "target.params3":
            ma[4] = v

    for w in b_s:
        if not ':' in w:
            mb[0] = w
            break
        k, v = w.split(":")
        v = v.replace("default", "")
        if k == "action":
            mb[0] = v
        if k == "target":
            mb[1] = v
        if k == "target.params1":
            mb[2] = v
        if k == "target.params2":
            mb[3] = v
        if k == "target.params3":
            mb[4] = v
    for i in range(5):
        if ma[i].find("$") == 0:
            continue
        if ma[i] != mb[i]:
            return False
    return True


def valid_model(test_batchs, test_labels, test_qids, recall_batchs,
                recall_zsds, batch_size=128):
    logging.info("start to validate model")

    index_q = list(chunks(range(0, len(test_batchs)), batch_size))
    index_data = list(chunks(range(0, len(recall_batchs)), batch_size))

    q_vector = sess.run(
        ori_feature, get_feed_dict_test(test_batchs[index_q[0]]))
    data_vector = sess.run(
        ori_feature, get_feed_dict_test(recall_batchs[index_data[0]]))

    # calculate semantic vectors
    for i in range(1, len(index_q)):
        temp_vector = sess.run(
            ori_feature, get_feed_dict_test(test_batchs[index_q[i]]))
        q_vector = np.vstack((q_vector, temp_vector))
    for i in range(1, len(index_data)):
        temp_vector = sess.run(
            ori_feature, get_feed_dict_test(recall_batchs[index_data[i]]))
        data_vector = np.vstack((data_vector, temp_vector))

    logging.info('calculata score')
    nbrs = NearestNeighbors(n_neighbors=1, algorithm='brute',
                            metric="cosine").fit(data_vector)
    distances, indices = nbrs.kneighbors(
        q_vector)  # the distances and indices of the nearest neighbor
    scores = distances.flatten()
    indices = indices.flatten()

    df = pd.DataFrame(data=list(zip(scores, indices, test_qids)),
                      columns=["score", "indice", "qid"])

    qid_score_label = df.loc[df.groupby(['qid'])['score'].idxmin()]['indice']
    qid_score_label = qid_score_label.values
    assert len(qid_score_label) == len(np.unique(test_qids))

    predict_kp = np.array(recall_zsds)[qid_score_label]
    _, index = np.unique(test_qids, return_index=True)
    real_kp = np.array(test_labels)[index]
    count = 0
    for a, b in zip(predict_kp, real_kp):
        if deal_cmp_line_sentence(a, b):
            count += 1
    acc = 1.0 * count / len(predict_kp)

    return acc


def cos_sim_np(q_v, c_v):
    v1 = np.dot(q_v, c_v)
    v2 = np.sqrt(np.dot(q_v, q_v)) * np.sqrt(np.dot(c_v, c_v)) + 1e-8

    return v1 / v2


def calc_sim(test_vec, recall_vecs):
    return np.array([cos_sim_np(test_vec[0], recall_vec) for recall_vec in recall_vecs])


def valid_real_recall(test_recall_info):
    count = 0
    count_ = 0
    logging.info("start to validate model")
    idx = 0
    # # add for out test result
    # ori_sents, ori_vectors, ori_labels, scores, results, cand_sents, cand_vectors, cand_labels
    # = [], [], [], [], [], [], [], []
    f_w = open('./log/result.txt', 'w',encoding='utf-8')

    for value in test_recall_info:
        test_sent, test_idxes, test_label = value[0]
        test_vector = sess.run(ori_feature, get_feed_dict_test(np.array([test_idxes])))

        recall_idx = [x[1] for x in value[1:]]
        recall_labels = [x[2] for x in value[1:]]
        recall_vectors = sess.run(ori_feature, get_feed_dict_test(np.array(recall_idx)))
        sims = calc_sim(test_vector, recall_vectors)
        max_idx = int(np.argmax(sims, axis=0))


        is_right = 1 if deal_cmp_line_sentence(recall_labels[max_idx].strip(),test_label.strip()) else 0
        f_w.write(str(max_idx)+'\t'+recall_labels[max_idx]+'\t'+str(is_right)+'\n')

        if recall_labels[max_idx].strip() == test_label.strip():
            count += 1
        if deal_cmp_line_sentence(recall_labels[max_idx].strip(),test_label.strip()):
            count_ +=1

        # # add for out test result
        # ori_sents.extend([test_sent]*len(recall_idx))
        # ori_vectors.extend([test_vector]*len(recall_idx))
        # ori_labels.extend([test_label]*len(recall_idx))
        # scores.extend(sims.tolist())
        # results.extend([int(deal_cmp_line_sentence(recall_label, test_label)) for recall_label in recall_labels])
        # cand_sents.extend([x[0] for x in value[1:]])
        # cand_vectors.extend(recall_vectors.tolist())
        # cand_labels.extend(recall_labels)

        idx += 1
    acc = count * 1.0 / len(test_recall_info)
    acc_ = count_ * 1.0 / len(test_recall_info)
    logging.info("start to out test info!")
    print(count, count_)
    # # add for out test result
    # record_score(ori_sents, ori_vectors, ori_labels, scores, results, cand_sents, cand_vectors,  cand_labels, acc)
    f_w.close()

    return acc, acc_


# load params to test and save it
def record_score(ori_sents, ori_vectors, ori_labels, scores, results, cand_sents, cand_vectors, cand_labels, acc):
    fo = open("test_result.txt", "w+", encoding="utf-8")
    fo.write("Acc equals {0}\nori_sent\tori_vector\tori_label\tscores\tresult\tcand_sent\tcand_vector\tcand_label\n".format(acc))
    count = 0

    for ori_sent, ori_vec, ori_label, score, result, cand_sent, cand_vec, cand_label\
            in zip(ori_sents, ori_vectors, ori_labels, scores, results, cand_sents, cand_vectors, cand_labels):
        if count < 10:
            fo.write("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\n".format(ori_sent, list(ori_vec), ori_label, score, result, cand_sent, list(cand_vec), cand_label))
        else:
            fo.write("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\n".format(ori_sent, [], ori_label, score, result, cand_sent, [], cand_label))
        count += 1

    fo.close()


def train():
    max_acc = 0
    for epoch in range(args.epoches):
        logger.info('epoch: {0}'.format(epoch))
        step = 0

        for ori_train, cand_train, neg_train in batch_iter(ori_quests,
                                                           cand_quests,
                                                           zsd_quests,
                                                           args.batch_size):
            start_time = time.time()

            feed_dict = get_feed_dict(
                ori_train, cand_train, neg_train, is_train=True)
            # print(feed_dict)
            # exit()
            _, loss_value, acc = sess.run(
                [train_op, loss, accuracy], feed_dict=feed_dict)

            if step % 100 == 0:
                time_elapsed = time.time() - start_time
                logger.info(
                    "epoch %s\tstep %s\tloss %s\tacc %s\t%6.5f secs/batch"
                    % (epoch, step, loss_value / args.batch_size, acc,
                       time_elapsed))
            step += 1
        # model_path = args.model_path + str(epoch) + "_" # + str(val_acc)
        # model_saver.save(sess, model_path)
        # logger.info('model has saved to: {0}'.format(model_path))

        try:
            if epoch % 2 == 0:
                # val_acc = valid_real_recall(test_recall_infos)
                logger.info("epoch {0}  val_acc {1}".format(epoch, 0))
                # save
                # if val_acc > max_acc:
                # max_acc = val_acc
                model_path = args.model_path + str(epoch) + "_"# + str(val_acc)
                model_saver.save(sess, model_path)
                logger.info('model has saved to: {0}'.format(model_path))
        except Exception as e:
            logger.error(e)


def test():
    for index in range(30,80,1):  # os.listdir('./model/jiexin/'):

        model_saver.restore(sess, './model_yj/'+str(index))
        try:
            val_acc, val_acc_ = valid_real_recall(test_recall_infos)
            logger.info("epoch {0}  val_acc {1}, val_acc2 {2}".format(0, val_acc, val_acc_))
        except Exception as e:
            logger.error(e)


if __name__ == '__main__':
    #train()
    test()

