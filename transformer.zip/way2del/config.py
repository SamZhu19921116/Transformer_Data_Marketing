# coding = utf-8


def add_data_args(parser):
    data = parser.add_argument_group('Data', 'data process args')
    data_path = './data/changsha/'  # "/lustre1/cog11/yanwang25/BERT_ft_poc_tk/data/"
    model_path = "/work/cog11/feixiao2/changsha_poc/"

    # ws args
    data.add_argument('--format', type=str, default='char', help='the format of input data, only can be word or char')
    data.add_argument('--train-file', type=str, default=data_path + 'plain_text.txt', help='train corpus file')
    data.add_argument('--test-file', type=str, default= './data_qa/label_data.txt',
                      help='test corpus file')
    data.add_argument('--recall-file', type=str, default= './data_qa/test_recall.txt',
                      help='recall corpus file')

    # BERT pre trained file
    # BERT_res_dir ='./bert_L6_jinrong/'#'/work/cog11/jxliu6/BERT/chinese/chinese_operator_L-6_H-256_A-8/'  # '/lustre1/cog11/jxliu6/model/BERT/chinese_L-12_H-768_A-12/'
    bert_model_path = "/work/cog11/jxliu6/BERT/chinese/chinese_operator_L-6_H-256_A-8_old/"
    data.add_argument('--vocab-file', type=str, default=bert_model_path + 'vocab.txt', help='vocab file')
    data.add_argument('--BERT-cfg', type=str, default=bert_model_path + 'bert_config.json', help='BERT config file')
    data.add_argument('--pre-model', type=str, default=bert_model_path, help='pre-trained BERT model dir')

    data.add_argument('--log-path', type=str, default='./log/' + "ahdx.log", help='log out path')  # train_loss_jiexin_sell
    data.add_argument('--model_path', type=str, default=model_path, help='model path')

    return data


def add_train_args(parser):
    train = parser.add_argument_group('train', 'training args')
    train.add_argument('--gpus', type=int, default=0, help='the gpus will be used, e.g "0,1,2,3"')
    train.add_argument('--lr', type=float, default=0.8, help='learning rate')
    train.add_argument('--batch_size', type=int, default=32, help='batch size of each batch')
    train.add_argument('--epoches', type=int, default=200, help='epoches')
    train.add_argument('--evaluate_every', type=int, default=1000, help='run evaluation')

    return train


def add_net_args(parser):
    net = parser.add_argument_group('net', 'network config args')
    net.add_argument('--embedding-size', type=int, default=100, help='embedding size')
    net.add_argument('--rnn-size', type=int, default=100, help='hidden size')
    net.add_argument('--num_rnn_layers', type=int, default=1, help='num of the rnn layers')
    # net.add_argument('--num_unroll_steps', type=int, default=30, help='length of the unroll steps in word')
    net.add_argument('--num_unroll_steps', type=int, default=60, help='length of the unroll steps in char')
    net.add_argument('--max_grad_norm', type=float, default=1., help='grad norm')
    net.add_argument('--attention_matrix_size', type=int, default=50, help='attention size')
    net.add_argument('--clipping_theta', type=float, default=0.0003, help='grad clip value')

    return net
