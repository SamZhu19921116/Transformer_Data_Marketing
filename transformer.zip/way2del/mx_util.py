# coding: utf-8
# __author__ = "xiaowang11"

import json
import tensorflow as tf
import numpy as np
import logging
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from data_helper import sent_to_idx, get_file_obj, chunks


# def calc_vector(lstm, ori_batch, ctx=mx.cpu()):
#     ori_batch = nd.array(ori_batch).as_in_context(ctx)
#     ori_feat = lstm(ori_batch)
#
#     return ori_feat.asnumpy()


def feature2cos_sim(feat_a, feat_b):
    """calculate cosnie similarity
    Args:
      feat_a: 2D tensor, (bs, C)
      feat_b: 2D tensor, (bs, C)
    
    Returns:
      cosine_similarity: cosine similarity, (bs,)
    """
    norm_q = tf.sqrt(tf.reduce_sum(tf.multiply(feat_a, feat_a), 1))
    norm_a = tf.sqrt(tf.reduce_sum(tf.multiply(feat_b, feat_b), 1))
    mul_q_a = tf.reduce_sum(tf.multiply(feat_a, feat_b), 1)
    cosine_similarit = tf.div(mul_q_a, tf.multiply(norm_q, norm_a)+1e-8)
    return cosine_similarit


# def cal_loss(dis_qq, dis_qq_):
#     losses = nd.maximum(0., 0.1 - (dis_qq - dis_qq_))
#
#     return nd.sum(losses)


def cal_loss(ori_pos_smt, ori_neg_smt):
    """calculate margin loss
    Args:
      ori_pos_smt: 1D tensor, (bs,)
      ori_neg_smt: 1D tensor, (bs,)
    
    Returns:
      loss: loss value, scalar
    """
    losses = tf.maximum(  # 0.05, 0.1 ro 0.2
      0.0, tf.subtract(0.1, tf.subtract(ori_pos_smt, ori_neg_smt)))
    # correct = tf.equal(0.0, losses)
    # accuracy = tf.reduce_mean(tf.cast(correct, "float"), name="accuracy")
    correct = tf.equal(0.0, losses)
    accuracy = tf.reduce_mean(tf.cast(correct, "float"), name="accuracy")
    return tf.reduce_sum(losses), accuracy


# # the function to verify consistency with C++ code
# def test_consistency(lstm, word2idx, num_unroll_steps, ctx=mx.cpu(), mode="word"):
#     words = [u"宽带_业务_个人_只能_宽带_故障",
#              u"呃_我_想_问_一_下_我_这个_是_一_个_月_的_他_说是_套餐_一_个_月_是_扣_多少_钱_呢",
#              u"我_家里_的_宽带_呀_没有_网络_啊_怎么_回_事_啊_给_我_查_一_下",
#              u"我_还有_话费_多少_啊"]
#     word_idx = []
#
#     for word in words:
#         ori_batch, ori_batch_len = sent_to_idx(word, word2idx, num_unroll_steps, mode=mode)
#         word_idx.append(ori_batch)
#     result = calc_vector(lstm, np.array(word_idx), ctx)
#     fo = get_file_obj("consistency.txt", "a+")
#     json.dump(result.tolist(), fo, ensure_ascii=False)
#     fo.write("\n")
#     fo.close()
