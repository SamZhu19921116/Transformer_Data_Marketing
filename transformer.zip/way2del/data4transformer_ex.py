#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

# 将 txt 中的 data 形成 transformer 所需的形式，

import threading
import glob
import os
# from scipy.spatial.distance import pdist

# 需要确保顺序的话，就在处理函数、写文件处加锁
# threadLock = threading.Lock()
# threadLock.acquire() # 加个同步锁就好了
# threadLock.release() # 释放

# 0: 全数据； 1: no both null； 2: no any null
MODE = 2

MODE_STR = {0:'all', 1:'no_both',2:'no_any'}

# 多线程运行函数
class MultiThread():
    def __init__(self, func, args):
        self.args = args
        self.num = len(args)
        if not isinstance(func, list):
            func = [func]
        if len(func) == 1:
            self.func = func*self.num

    def run(self):
        thr = []
        for i in range(self.num):
            cur_func = self.func[i]
            cur_args = self.args[i]
            t = threading.Thread(target=cur_func, args=cur_args)
            thr.append(t)
        [t.start() for t in thr]
        [t.join() for t in thr]
        print('INFO:-------------process finished-------------')
        return 0


def main_func(in_file, out_fp, vocabs):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # 这里插入处理函数
            result = data_processer(line, vocabs, MODE)
            out_fp.write(result)


def data_processer(line, vocabs, mode):
    items = line.strip().split('\t')
    if items[0] == '0':
        label = 'neg'
    elif items[0] == '1':
        label = 'pos'
    for i in range(2, 4):
        if items[i] == 'null':
            items[i] = ''
        vocabs[0].add(items[i])
        vocabs[i-1].add(items[i])
    for i in range(4, 6):
        if items[i] == 'null':
            items[i] = ''
            any_null = True
            elmts = ['']
        else:
            elmts = items[i].split(',')
        vocabs[0].update(elmts)
        vocabs[i-1].update(elmts)
    any_null = not (items[4] and items[5])
    both_null = not (items[4] or items[5])
    if mode==2 and any_null:
        return ''
    elif mode==1 and both_null:
        return ''
    tmp = items[2] + ',' + items[3] + ',' + items[4] + ',' + items[5]
    result = label + '\t' + tmp + '\n'
    return result


def main_func_novocab(in_file, out_fp):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # 这里插入处理函数
            result = data_processer_novocab(line, MODE)
            out_fp.write(result)


def data_processer_novocab(line, mode):
    items = line.strip().split('\t')
    if items[0] == '0':
        label = 'neg'
    elif items[0] == '1':
        label = 'pos'
    for i in range(2, 4):
        if items[i] == 'null':
            items[i] = ''
    for i in range(4, 6):
        if items[i] == 'null':
            items[i] = ''
            any_null = True
    any_null = not (items[4] and items[5])
    both_null = not (items[4] or items[5])
    if mode==2 and any_null:
        return ''
    elif mode==1 and both_null:
        return ''
    tmp = items[2] + ',' + items[3] + ',' + items[4] + ',' + items[5]
    result = label + '\t' + tmp + '\n'
    return result


def main_func_vocab(in_file, vocabs):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # 这里插入处理函数
            vocab_processer(line, vocabs)


def vocab_processer(line, vocabs):
    items = line.strip().split('\t')
    for i in range(2, 4):
        if items[i] == 'null':
            items[i] = ''
        if items[i] not in vocabs:
            vocabs[items[i]] = 0
        else:
            vocabs[items[i]] = vocabs[items[i]] + 1
    for i in range(4, 6):
        if items[i] == 'null':
            items[i] = ''
            any_null = True
            elmts = ['']
        else:
            elmts = items[i].split(',')
        for elm in elmts:
            if elm not in vocabs:
                vocabs[elm] = 0
            else:
                vocabs[elm] = vocabs[elm] + 1
    return vocabs


def sort_vacob_by_freq(vocab):
    items = sorted(vocab.items(), key=lambda d:d[1], reverse = False)
    return items


def sort_vacob_by_key(vocab):
    items = sorted(vocab.items(), key=lambda d:d[0], reverse = False)
    return items


def save_vacob(vocab, file_name):
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            fp.write(v+'\n')


def save_vacob_sort_value_limit(vocab, file_name, minv=1, use_sort=True):
    if use_sort:
        vocab = sort_vacob_by_value(vocab)
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            if v[1] <= minv:
                break
            fp.write(v[0]+'\n')


def save_vacob_limit(vocab, file_name, limit=1, use_sort=True):
    if use_sort:
        vocab = sort_vacob_by_key(vocab)
    vocab.insert(0, ('[MASK]', limit+1))
    vocab.insert(0, ('[SEP]', limit+1))
    vocab.insert(0, ('[CLS]', limit+1))
    vocab.insert(0, ('[UNK]', limit+1))
    vocab.insert(0, ('[PAD]', limit+1))
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            if v[1] <= limit:
                continue
            fp.write(v[0]+'\n')

if __name__ == '__main__':
    train_dir = '/disk1/sdsong/20211214/traindata/'
    test_dir = '/disk1/sdsong/20211214/testdata/'
    # train_dir = './traindata/'
    # test_dir = './testdata/'
    target_dir = './data_zaxd/20211214/{}/'.format(MODE_STR[MODE])
    os.makedirs(target_dir, exist_ok=True)
    train_file_list = glob.glob(train_dir+'*')
    # test_file_list = glob.glob(test_dir+'*')

    # # 训练集
    # fp_tmp = open(target_dir+'train_data', "w", encoding='utf-8')
    # fp_tmp.close()
    # out_fp = open(target_dir+'train_data', 'a', encoding='utf-8')
    # args = []
    # vocabs = [set(), set(), set(), set(), set()]
    # for i in train_file_list:
    #     args.append((i, out_fp, vocabs))
    # mthread = MultiThread(main_func, args)
    # mthread.run()
    # out_fp.close()
    # for i, v in enumerate(vocabs):
    #     v = list(v)
    #     vocabs[i] = v
    #     v.sort()
    # vocabs[0].insert(0, '[MASK]')
    # vocabs[0].insert(0, '[SEP]')
    # vocabs[0].insert(0, '[CLS]')
    # vocabs[0].insert(0, '[UNK]')
    # vocabs[0].insert(0, '[PAD]')
    # # print(vocabs)

    # # 保存词汇表
    # vocab_names = ['all_vocab.txt', 'train_dvc.txt', 'train_area.txt', 'train_app.txt','train_behavior.txt']
    # for i in range(len(vocabs)):
    #     vocab_path = target_dir + vocab_names[i]
    #     save_vacob(vocabs[i], vocab_path)
        
    # # 测试集
    # fp_tmp = open(target_dir+'test_data', "w", encoding='utf-8')
    # fp_tmp.close()
    # out_fp = open(target_dir+'test_data', 'a', encoding='utf-8')
    # args = []
    # for i in test_file_list:
    #     args.append((i, out_fp))
    # mthread = MultiThread(main_func_novocab, args)
    # mthread.run()
    # out_fp.close()

    # 尝试重新分析总词汇表
    vocabs = dict()
    args = []
    for i in train_file_list:
        args.append((i, vocabs))
    mthread = MultiThread(main_func_vocab, args)
    mthread.run()
    limit = 1
    vocab_path = target_dir + 'all_vocab_gt{}.txt'.format(limit)
    save_vacob_limit(vocabs, vocab_path, limit)
