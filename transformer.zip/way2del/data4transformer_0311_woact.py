#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

# save txt data into transformer needed: label \t string，

import threading
import glob
import os
from collections import OrderedDict
import re

# if need to ensure the order, add lock as the main process func
# threadLock = threading.Lock()
# threadLock.acquire() # add lock
# threadLock.release() # release 

# 0: all;  1: no both null;  2: no any null
MODE = 1

MODE_STR = {0:'all', 1:'no_both',2:'no_any'}

APP_NUM = 0
APP_ACT_NUM = 0

class AppAct():
    def __init__(self, app_name, act=0) -> None:
        self.app_name = app_name
        self.act = act
    
    def __str__(self) -> str:
        # return self.app_name+':'+str(self.act)
        return self.app_name

    def __repr__(self) -> str:
        # return self.app_name+':'+str(self.act)
        return self.app_name

# multi-threads
class MultiThread():
    def __init__(self, func, args):
        self.args = args
        self.num = len(args)
        if not isinstance(func, list):
            func = [func]
        if len(func) == 1:
            self.func = func*self.num

    def run(self):
        thr = []
        for i in range(self.num):
            cur_func = self.func[i]
            cur_args = self.args[i]
            t = threading.Thread(target=cur_func, args=cur_args)
            thr.append(t)
        [t.start() for t in thr]
        [t.join() for t in thr]
        print('INFO:-------------processing finished -------------')
        return 0


def main_func(in_file, out_fp, vocabs):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # here is the processing func
            result = data_processer(line, vocabs, MODE)
            out_fp.write(result)


def data_processer(line, vocabs, mode):
    app_act_num = 0
    app_num = 0
    items = line.strip().split('\t')
    valid_labels = ['neg', 'pos1', 'pos2', 'pos3', 'pos4', 'pos5']
    label = valid_labels[int(items[0])]
    for i in range(2, 4):
        # if items[i] == 'null':
        #     items[i] = ''
        vocabs[0].add(items[i])
        vocabs[i-1].add(items[i])
    both_null = [1,1]
    # num_cols = len(items)
    app_install_idx = [4]
    app_install = OrderedDict()
    for i in app_install_idx:
        if items[i] == 'null':
            # items[i] = ''
            both_null[i-4] = ''
            # any_null = True
            elmts = ['null']
        else:
            elmts = items[i].split(',')
            for elm in elmts:
                if elm == '众安小贷':
                    continue
                app_install.update({elm:AppAct(elm)})
        vocabs[0].update(elmts)
        vocabs[i-1].update(elmts)
        # app_install.update(elmts)
    for i in range(5, 6):
        if items[i] == 'null':
            # items[i] = ''
            both_null[i-4] = ''
            # any_null = True
            elmts = ['null']
            app_names = ['null']
        else:
            elmts = items[i].split(',')
            app_names = set()
            for el in elmts:
                try:
                    app_act  = re.split(':(\d+)$', el)
                    if len(app_act)==3:
                        app_name=app_act[0]
                        act=int(app_act[1])
                    elif len(app_act)==2:
                        app_name=app_act[0]
                        if app_act[1]=='':
                            act=0
                        else:
                            act=int(app_act[1])
                    elif len(app_act)==1:
                        app_name=app_act[0]
                        act=0
                    else:
                        app_name='UNK'
                        act=0

                except:
                    print(el)
                    # app_name=input()
                    # act=int(input())
                if app_name == '众安小贷':
                    continue
                app_names.add(app_name)
                app_install.update({app_name:AppAct(app_name, act)})
                if int(act)>0:
                    app_act_num = app_act_num + 1
        vocabs[0].update(app_names)
        vocabs[i-2].update(app_names)
    app_num = app_num + len(app_install)
    app_str = ''
    for app_ins in app_install:
        app_str = app_str + str(app_install[app_ins]) + ','
    app_str = app_str[0:-1]
    vocabs[-1][0] = vocabs[-1][0] + app_num
    vocabs[-1][1] = vocabs[-1][1] + app_act_num
    # print(app_num, app_act_num, vocabs[-1])
    for i in range(6, 7):
        if items[i] == 'null':
            # items[i] = ''
            # any_null = True
            elmts = ['null']
        else:
            elmts = items[i].split(',')
        vocabs[0].update(elmts)
        vocabs[i-2].update(elmts)
    any_null = not (both_null[0] and both_null[1])
    both_null = not (both_null[0] or both_null[1])
    if mode==2 and any_null:
        return '' # label + '\t' + '' + '\n'
    elif mode==1 and both_null:
        return '' # label + '\t' + '' + '\n'
    tmp = items[2] + ',' + items[3] + ',' + app_str + ',' + items[6]

    tmp = re.sub(',众安小贷:\d*', '', tmp)
    tmp = re.sub('众安小贷:\d*,', '', tmp)
    tmp = re.sub(',null:\d*', '', tmp)
    tmp = re.sub('null:\d*,', '', tmp)
    tmp = tmp.replace(',null','').replace('null,', '')
    result = label + '\t' + tmp + '\n'
    return result


def save_vacob(vocab, file_name):
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            fp.write(v+'\n')



if __name__ == '__main__':
    train_dir = '/disk1/sdsong/20220311/traindata/'
    test_dir = '/disk1/sdsong/20220311/testdata/'
    # train_dir = './data/20220311/testdata/'
    # train_dir = './traindata'
    # test_dir = './testdata'
    target_dir = './data_zaxd/20220311/{}_wocat/'.format(MODE_STR[MODE])
    os.makedirs(target_dir, exist_ok=True)
    train_file_list = glob.glob(train_dir+'*.txt')
    test_file_list = glob.glob(test_dir+'*.txt')
#
#    # training dataset
#    fp_tmp = open(target_dir+'train_data', "w", encoding='utf-8')
#    fp_tmp.close()
#    out_fp = open(target_dir+'train_data', 'a', encoding='utf-8')
#    args = []
#    vocabs = [set(), set(), set(), set(), set(), [0,0]]
#    for i in train_file_list:
#        args.append((i, out_fp, vocabs))
#    mthread = MultiThread(main_func, args)
#    mthread.run()
#    out_fp.close()
#    for i, v in enumerate(vocabs):
#        v = list(v)
#        vocabs[i] = v
#        v.sort()
#    vocabs[0].insert(0, '[MASK]')
#    vocabs[0].insert(0, '[SEP]')
#    vocabs[0].insert(0, '[CLS]')
#    vocabs[0].insert(0, '[UNK]')
#    vocabs[0].insert(0, '[PAD]')
#    # print(vocabs)
#    num = vocabs[-1]
#    vocabs.remove(num)
#    # save vocab
#    vocabs.append(range(0,32))
#    vocab_names = ['all_vocab.txt', 'train_dvc.txt', 'train_area.txt', 'train_app.txt','train_behavior.txt', 'train_active.txt']
#    for i in range(len(vocab_names)):
#        vocab_path = target_dir + vocab_names[i]
#        save_vacob(vocabs[i], vocab_path)
        
    # test dataset
    fp_tmp = open(target_dir+'test_data', "w", encoding='utf-8')
    fp_tmp.close()
    out_fp = open(target_dir+'test_data', 'a', encoding='utf-8')
    args = []
    vocabs = [set(), set(), set(), set(), set(), [0,0]]
    for i in test_file_list:
        args.append((i, out_fp, vocabs))
    mthread = MultiThread(main_func, args)
    mthread.run()
    out_fp.close()

