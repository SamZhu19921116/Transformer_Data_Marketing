#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

# save txt data into transformer needed: label \t string，

import threading
import glob
import os

# if need to ensure the order, add lock as the main process func
# threadLock = threading.Lock()
# threadLock.acquire() # add lock
# threadLock.release() # release 

# 0: all;  1: no both null;  2: no any null
MODE = 1

MODE_STR = {0:'all', 1:'no_both',2:'no_any'}

# multi-threads
class MultiThread():
    def __init__(self, func, args):
        self.args = args
        self.num = len(args)
        if not isinstance(func, list):
            func = [func]
        if len(func) == 1:
            self.func = func*self.num

    def run(self):
        thr = []
        for i in range(self.num):
            cur_func = self.func[i]
            cur_args = self.args[i]
            t = threading.Thread(target=cur_func, args=cur_args)
            thr.append(t)
        [t.start() for t in thr]
        [t.join() for t in thr]
        print('INFO:-------------processing finished -------------')
        return 0


def main_func(in_file, out_fp, vocabs, phase='train'):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # here is the processing func
            result = data_processer(line, vocabs, MODE, phase)
            out_fp.write(result)


def data_processer(line, vocabs, mode, phase='train'):
    items = line.strip().split('\t')
    if items[0] == '0':
        label = 'neg'
    elif items[0] == '1':
        label = 'pos'
    # if items[4]=='null' and items[5]=='null':
    #    return ''
    pack_name = items[4]
    if phase=='train':
        if pack_name == 'null':
            return ''
    if phase=='eval':
        if (items[4]=='null' or items[-1]=='null'):
            return ''
    if phase=='test':
        if pack_name=='null' and items[-3]=='null':
            return ''
    elmts = items[-3].split(',')
    vocabs[0].update(elmts)
    vocabs[1].update(elmts)
    elmts = pack_name.split(',')
    vocabs[0].update(elmts)
    vocabs[2].update(elmts)
    tmp = pack_name + ',' + items[-3] 
    tmp = tmp.replace('null,','').replace(',null', '')
    result = label + '\t' + tmp + '\n'
    return result


def save_vacob(vocab, file_name):
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            fp.write(v+'\n')



if __name__ == '__main__':
    train_dir = '/disk1/assun/modelinfo/featureBuild/20220329/20220330_yqg-intent-addpack-posandneg2random-predictdata/traindata/'
    test_dir = '/disk1/assun/modelinfo/featureBuild/20220329/20220330_yqg-intent-addpack-posandneg2random-predictdata/testdata/'
    # train_dir = './traindata'
    # test_dir = './testdata'
    target_dir = './data_zaxd/20220329/yqg-intent-posandneg2random/{}/'.format(MODE_STR[MODE])
    os.makedirs(target_dir, exist_ok=True)
    train_file_list = glob.glob(train_dir+'*.txt')
    test_file_list = glob.glob(test_dir+'*.txt')

    # training dataset
    fp_tmp = open(target_dir+'train_data', "w", encoding='utf-8')
    fp_tmp.close()
    out_fp = open(target_dir+'train_data', 'a', encoding='utf-8')
    args = []
    vocabs = [set(), set(), set(), set(), set()]
    for i in train_file_list:
        args.append((i, out_fp, vocabs, 'train'))
    mthread = MultiThread(main_func, args)
    mthread.run()
    out_fp.close()
    for i, v in enumerate(vocabs):
        v = list(v)
        vocabs[i] = v
        v.sort()
    vocabs[0].insert(0, '[MASK]')
    vocabs[0].insert(0, '[SEP]')
    vocabs[0].insert(0, '[CLS]')
    vocabs[0].insert(0, '[UNK]')
    vocabs[0].insert(0, '[PAD]')
    # print(vocabs)

    # save vocab
    vocab_names = ['all_vocab.txt', 'train_behavior.txt', 'train_app.txt']
    for i in range(len(vocab_names)):
        vocab_path = target_dir + vocab_names[i]
        save_vacob(vocabs[i], vocab_path)
        
    # test dataset
    fp_tmp = open(target_dir+'test_data', "w", encoding='utf-8')
    fp_tmp.close()
    out_fp = open(target_dir+'test_data', 'a', encoding='utf-8')
    args = []
    vocabs = [set(), set(), set(), set(), set()]
    for i in test_file_list:
        args.append((i, out_fp, vocabs, 'test'))
    mthread = MultiThread(main_func, args)
    mthread.run()
    out_fp.close()

    # eval dataset
    fp_tmp = open(target_dir+'eval_data', "w", encoding='utf-8')
    fp_tmp.close()
    out_fp = open(target_dir+'eval_data', 'a', encoding='utf-8')
    args = []
    vocabs = [set(), set(), set(), set(), set()]
    for i in test_file_list:
        args.append((i, out_fp, vocabs, 'eval'))
    mthread = MultiThread(main_func, args)
    mthread.run()
    out_fp.close()
