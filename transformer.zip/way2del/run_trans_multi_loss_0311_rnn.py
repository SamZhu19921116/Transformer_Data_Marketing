#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""BERT finetuning runner."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import re
import math
import csv
import codecs
import os
import random
from matplotlib import use
import numpy as np
# import modeling as modeling
import modeling_plus as modeling
import optimization
import tokenization
import tensorflow as tf
from sklearn.metrics import roc_auc_score
from sklearn import metrics
import time
import app2categary as a2c 
flags = tf.flags

FLAGS = flags.FLAGS

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

base_str = '20220311/no_both_wocat/'
data_dir_ = "./data_zaxd/"+base_str
load_model_idx = '_rnn'

flags.DEFINE_string(
    "data_dir", data_dir_,
    "The input data dir. Should contain the .tsv files (or other data files) "
    "for the task.")

flags.DEFINE_string(
        "result_dir", "./result_zaxd/"+base_str[0:-1]+'_rnn/',
    "The input data dir. Should contain the .tsv files (or other data files) "
    "for the task.")

flags.DEFINE_string("task_name", "call", "The name of the task to train.")

flags.DEFINE_string(
  "vocab_file",
  data_dir_+"all_vocab_gt1.txt",
  "The vocabulary file that the BERT model was trained on.")
flags.DEFINE_string(
    "init_checkpoint",
    "",
    "Initial checkpoint (usually from a pre-trained BERT model).")
flags.DEFINE_string(
    "bert_config_file",
    "./configs/bert_config.json",
    "The config json file corresponding to the pre-trained BERT model. "
    "This specifies the model architecture.")

# flags.DEFINE_string(
#   "vocab_file",
#   "/work/cog11/jxliu6/BERT/chinese/chinese_dialog_L-12_H-768_A-12/vocab.txt",
#   "The vocabulary file that the BERT model was trained on.")
# flags.DEFINE_string(
#     "init_checkpoint",
#     "/work/cog11/jxliu6/BERT/chinese/chinese_dialog_L-12_H-768_A-12",
#     "Initial checkpoint (usually from a pre-trained BERT model).")
# flags.DEFINE_string(
#     "bert_config_file",
#     "/work/cog11/jxliu6/BERT/chinese/chinese_dialog_L-12_H-768_A-12/bert_config.json",
#     "The config json file corresponding to the pre-trained BERT model. "
#     "This specifies the model architecture.")

flags.DEFINE_string(
    "output_dir", "./checkpoint/"+base_str[0:-1]+'_rnn/',
    "The output directory where the model checkpoints will be written.")

## Other parameters

flags.DEFINE_bool(
    "do_lower_case", True,
    "Whether to lower case the input text. Should be True for uncased "
    "models and False for cased models.")

flags.DEFINE_integer(
    "max_seq_length", 200,
    "The maximum total input sequence length after WordPiece tokenization. "
    "Sequences longer than this will be truncated, and sequences shorter "
    "than this will be padded.")

# flags.DEFINE_bool("do_train", True, "Whether to run training.")
# 
# flags.DEFINE_bool("do_eval", True, "Whether to run eval on the dev set.")
# 
# flags.DEFINE_bool(
#   "do_predict", False,
#   "Whether to run the model in inference mode on the test set.")

flags.DEFINE_bool("do_train", True, "Whether to run training.")

flags.DEFINE_bool("do_eval", True, "Whether to run eval on the dev set.")

flags.DEFINE_bool(
  "do_predict", False,
  "Whether to run the model in inference mode on the test set.")

# flags.DEFINE_integer("train_batch_size", 8, "Total batch size for training.")
flags.DEFINE_integer("train_batch_size", 32, "Total batch size for training.")

flags.DEFINE_integer("eval_batch_size", 32, "Total batch size for eval.")

flags.DEFINE_integer("predict_batch_size", 32, "Total batch size for predict.")

flags.DEFINE_float("learning_rate", 3e-5, "The initial learning rate for Adam.")

flags.DEFINE_float("num_train_epochs", 10.0,
                   "Total number of training epochs to perform.")

flags.DEFINE_integer("check_freq", 1000, "check frequency")

flags.DEFINE_float(
    "warmup_proportion", 0.1,
    "Proportion of training to perform linear learning rate warmup for. "
    "E.g., 0.1 = 10% of training.")

flags.DEFINE_integer("save_checkpoints_steps", 1000,
                     "How often to save the model checkpoint.")

flags.DEFINE_integer("iterations_per_loop", 1000,
                     "How many steps to make in each estimator call.")

flags.DEFINE_bool("use_tpu", False, "Whether to use TPU or GPU/CPU.")

tf.flags.DEFINE_string(
    "tpu_name", None,
    "The Cloud TPU to use for training. This should be either the name "
    "used when creating the Cloud TPU, or a grpc://ip.address.of.tpu:8470 "
    "url.")

tf.flags.DEFINE_string(
    "tpu_zone", None,
    "[Optional] GCE zone where the Cloud TPU is located in. If not "
    "specified, we will attempt to automatically detect the GCE project from "
    "metadata.")

tf.flags.DEFINE_string(
    "gcp_project", None,
    "[Optional] Project name for the Cloud TPU-enabled project. If not "
    "specified, we will attempt to automatically detect the GCE project from "
    "metadata.")

tf.flags.DEFINE_string("master", None, "[Optional] TensorFlow master URL.")

flags.DEFINE_integer(
    "num_tpu_cores", 8,
    "Only used if `use_tpu` is True. Total number of TPU cores to use.")

a2c_table, pri_lbls, sec_lbls = a2c.load_rough_cate_table()

# a2c.build_cate_vocab()

class InputExample(object):
  """A single training/test example for simple sequence classification."""

  def __init__(self, guid, text_a, text_b=None, label=None):
    """Constructs a InputExample.

    Args:
      guid: Unique id for the example.
      text_a: string. The untokenized text of the first sequence. For single
        sequence tasks, only this sequence must be specified.
      text_b: (Optional) string. The untokenized text of the second sequence.
        Only must be specified for sequence pair tasks.
      label: (Optional) string. The label of the example. This should be
        specified for train and dev examples, but not for test examples.
    """
    self.guid = guid
    self.text_a = text_a
    self.text_b = text_b
    self.label = label


class InputFeatures(object):
  """A single set of features of data."""

  def __init__(self, input_ids, input_mask, segment_ids, label_id, extra_ids=None):
    self.input_ids = input_ids
    self.input_mask = input_mask
    self.segment_ids = segment_ids
    self.label_id = label_id
    self.extra_ids = extra_ids

  def __repr__(self):
    object_str = ''
    object_str += 'input_ids: {0}\n'.format(self.input_ids)
    object_str += 'input_mask: {0}\n'.format(self.input_mask)
    object_str += 'segment_ids: {0}\n'.format(self.segment_ids)
    object_str += 'label_id: {0}'.format(self.label_id)
    object_str += 'extra_ids: {0}'.format(self.extra_ids)
    return object_str


class DataProcessor(object):
  """Base class for data converters for sequence classification data sets."""

  def get_train_examples(self, data_dir):
    """Gets a collection of `InputExample`s for the train set."""
    raise NotImplementedError()

  def get_dev_examples(self, data_dir):
    """Gets a collection of `InputExample`s for the dev set."""
    raise NotImplementedError()

  def get_test_examples(self, data_dir):
    """Gets a collection of `InputExample`s for prediction."""
    raise NotImplementedError()

  def get_labels(self):
    """Gets the list of labels for this data set."""
    raise NotImplementedError()

  @classmethod
  def _read_tsv(cls, input_file, quotechar=None):
    """Reads a tab separated value file."""
    with tf.gfile.Open(input_file, "r") as f:
    #   reader = csv.reader(f, delimiter="\t", quotechar=quotechar)
      r_lines = f.readlines()
      lines = []
      for line in r_lines:
        line = line.strip().split('\t')
        if line[1] == "":
          line_tmp = [line[0]]
          line = line_tmp
        lines.append(line)
      return lines


class SentimentProcessor(DataProcessor):
  """用户数据集
  """

  def get_train_examples(self, data_dir):
    """See base class."""
    return self._create_examples(
        self._read_tsv(os.path.join(data_dir, "train.tsv")),
      "train", shuffle=True)

  def get_dev_examples(self, data_dir):
    """See base class."""
    return self._create_examples(
        self._read_tsv(os.path.join(data_dir, "dev.tsv")), "dev")

  def get_test_examples(self, data_dir):
    """See base class."""
    return self._create_examples(
      self._read_tsv(os.path.join(data_dir, "test.tsv")), "test")

  @staticmethod
  def get_labels(self):
    """See base class.
      len(labels) = 37.
    """
    return ["0", "1"]

  def _create_examples(self, lines, set_type, shuffle=False):
    """Creates examples for the training and dev sets."""
    # shuffle data
    if shuffle:
      random.seed(1337)
      random.shuffle(lines)
    examples = []
    for (i, line) in enumerate(lines):
      guid = "%s-%s" % (set_type, i)
      if len(line) == 1:
        text_a = "[PAD]"
      else:
        text_a = tokenization.convert_to_unicode(line[1])
      label = tokenization.convert_to_unicode(line[0])
      examples.append(
          InputExample(guid=guid, text_a=text_a, text_b=None, label=label))
    return examples


class CallProcessor(DataProcessor):
  """用户外呼数据集
  """
  def get_train_examples(self, data_dir):
    """See base class."""
    return self._create_examples(
        self._read_tsv(os.path.join(data_dir, "train_data")),
      "train", shuffle=True)

  def get_dev_examples(self, data_dir):
    """See base class."""
    return self._create_examples(
        self._read_tsv(os.path.join(data_dir, "test_data")), "dev")

  def get_test_examples(self, data_dir):
    """See base class."""
    return self._create_examples(
      self._read_tsv(os.path.join(data_dir, "test_data")), "test")

  @staticmethod
  def get_labels():
    """See base class.
      len(labels) = 37.
    """
    return ["neg", "pos1", "pos2", "pos3", "pos4", "pos5"]
    # label_list = []
    # label_file = open('label_ahdx.txt','r',encoding='utf-8')
    # label_lines = label_file.readlines()
    # for label in label_lines:
    #     label_list.append(label.strip())
    # #for i in range(811418):
    # #    label_list.append(i)
    # label_list.append('ERROR')
    # return label_list

  def _create_examples(self, lines, set_type, shuffle=False):
    """Creates examples for the training and dev sets."""
    # shuffle data
    if shuffle:
      random.seed(1337)
      random.shuffle(lines)
    examples = []
    for (i, line) in enumerate(lines):
      guid = "%s-%s" % (set_type, i)
      if len(line) == 1:
        text_a = "[PAD]"
      else:
        text_a = tokenization.convert_to_unicode(line[1])
      label = tokenization.convert_to_unicode(line[0])
      examples.append(
          InputExample(guid=guid, text_a=text_a, text_b=None, label=label))
    return examples


def replace_num(text):
  """将中文数字替换为阿拉伯数字
  Args:
    text: str, 待替换文本

  Returns:
    text_rep: str, 替换后的文本
  """
  if len(text) < 2:
    return text
  replace_dict = {
    '零': '0', '一': '1', '二': '2', '三': '3', '四': '4', '五': '5', '六': '6',
    '七': '7', '八': '8', '九': '9', '幺': '1', '十': '10', '百': '1',
    '千': '1', '万': '1', '点': '1', '两': '1'}
  text_rep = ''
  for c in text:
    if c in replace_dict:
      text_rep += replace_dict[c]
    else:
      text_rep += c
  pattern = re.compile('[^0-9a-zA-Z]')  # 数字、字母替换为`NUM`
  patter_num = re.compile('[0-9a-zA-Z]+')
  # text_rep = pattern.sub('NUM', text_rep)
  if pattern.search(text_rep):
    return text
  else:
    return patter_num.sub('num', text_rep)


def convert_single_example(ex_index, example, label_list, max_seq_length,
                           tokenizer, use_extra=0):
  """Converts a single `InputExample` into a single `InputFeatures`."""
  label_map = {}
  for (i, label) in enumerate(label_list):
    label_map[label.lower()] = i

  # 替换中文数字和纯字母
  # text_a = ' '.join([replace_num(word) for word in example.text_a.split()])
  text_a = ' '.join([word for word in example.text_a.split()])
  # tokens_a = tokenizer.tokenize(text_a)
  tokens_a = list(text_a.split(','))
  tokens_b = None
  if example.text_b:
    tokens_b = tokenizer.tokenize(example.text_b)

  if tokens_b:
    # Modifies `tokens_a` and `tokens_b` in place so that the total
    # length is less than the specified length.
    # Account for [CLS], [SEP], [SEP] with "- 3"
    _truncate_seq_pair(tokens_a, tokens_b, max_seq_length - 3)
  else:
    # Account for [CLS] and [SEP] with "- 2"
    if len(tokens_a) > max_seq_length - 2:
      tokens_a = tokens_a[0:(max_seq_length - 2)]

  # The convention in BERT is:
  # (a) For sequence pairs:
  #  tokens:   [CLS] is this jack ##son ##ville ? [SEP] no it is not . [SEP]
  #  type_ids: 0     0  0    0    0     0       0 0     1  1  1  1   1 1
  # (b) For single sequences:
  #  tokens:   [CLS] the dog is hairy . [SEP]
  #  type_ids: 0     0   0   0  0     0 0
  #
  # Where "type_ids" are used to indicate whether this is the first
  # sequence or the second sequence. The embedding vectors for `type=0` and
  # `type=1` were learned during pre-training and are added to the wordpiece
  # embedding vector (and position vector). This is not *strictly* necessary
  # since the [SEP] token unambiguously separates the sequences, but it makes
  # it easier for the model to learn the concept of sequences.
  #
  # For classification tasks, the first vector (corresponding to [CLS]) is
  # used as as the "sentence vector". Note that this only makes sense because
  # the entire model is fine-tuned.
  tokens = []
  segment_ids = []
  tokens.append("[CLS]")
  segment_ids.append(0)
  extra_ids = []
  for ex_cnt in range(use_extra):
    extra_ids.append([0])
  for token in tokens_a:
    ex_token = token.split(':')
    tokens.append(ex_token[0])
    if use_extra:
      for ex_cnt in range(1, use_extra+1):
        if len(ex_token)<ex_cnt+1:
          extra_ids[ex_cnt-1].append(0)
        else:
          ext = ex_token[ex_cnt]
          extra_ids[ex_cnt-1].append(int(ext)+1)
    if ex_token[0] in a2c_table:
      pri_lbl, sec_lbl = a2c_table[ex_token[0]]
      pri_lbl_id = pri_lbls.index(pri_lbl)
      segment_ids.append(pri_lbl_id)
    else:
      segment_ids.append(0)
  tokens.append("[SEP]")
  segment_ids.append(0)
  if use_extra:
    for ex_cnt in range(use_extra):
      extra_ids[ex_cnt].append(0)

  if tokens_b:
    for token in tokens_b:
      tokens.append(token)
      segment_ids.append(1)
    tokens.append("[SEP]")
    segment_ids.append(1)

  input_ids = tokenizer.convert_tokens_to_ids(tokens)

  # The mask has 1 for real tokens and 0 for padding tokens. Only real
  # tokens are attended to.
  input_mask = [1] * len(input_ids)

  # Zero-pad up to the sequence length.
  while len(input_ids) < max_seq_length:
    input_ids.append(0)
    input_mask.append(0)
    segment_ids.append(0)
    if use_extra:
      for ex_cnt in range(use_extra):
        extra_ids[ex_cnt].append(0)

  assert len(input_ids) == max_seq_length
  assert len(input_mask) == max_seq_length
  assert len(segment_ids) == max_seq_length
  if use_extra:
      for ex_cnt in range(use_extra):
        assert len(extra_ids[ex_cnt]) == max_seq_length

  if example.label.lower() not in label_map:
    label_id = label_map['ERROR'.lower()]
  else:
    label_id = label_map[example.label.lower()]

  if ex_index < 5:
    tf.logging.info("*** Example ***")
    tf.logging.info("guid: %s" % (example.guid))
    tf.logging.info("tokens: %s" % " ".join(
        [tokenization.printable_text(x) for x in tokens]))
    tf.logging.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
    tf.logging.info("input_mask: %s" % " ".join([str(x) for x in input_mask]))
    tf.logging.info("segment_ids: %s" % " ".join([str(x) for x in segment_ids]))
    tf.logging.info("label: %s (id = %d)" % (example.label, label_id))

  feature = InputFeatures(
      input_ids=input_ids,
      input_mask=input_mask,
      segment_ids=segment_ids,
      label_id=label_id,
      extra_ids=extra_ids,
      )
  # print(tokens)
  # print(feature)
  # exit()
  return feature


def convert_examples_to_features(
    examples, label_list, max_seq_length, tokenizer, use_extra=0):
  """Convert a set of `InputExample`s to a TFRecord file."""

  data_count = len(examples)
  feature_input_ids = np.zeros(
    shape=(data_count, max_seq_length), dtype='int32')
  feature_input_mask = np.zeros(
    shape=(data_count, max_seq_length), dtype='int32')
  feature_segment_ids = np.zeros(
    shape=(data_count, max_seq_length), dtype='int32')
  label_ids = np.zeros(shape=(data_count,), dtype='int32')
  feature_extra_ids = []
  for ex_cnt in range(use_extra):
    feature_extra_ids.append(np.zeros(
    shape=(data_count, max_seq_length), dtype='int32'))
  for (ex_index, example) in enumerate(examples):
    feature = convert_single_example(ex_index, example, label_list,
                                     max_seq_length, tokenizer, use_extra)
    feature_input_ids[ex_index] = feature.input_ids
    feature_input_mask[ex_index] = feature.input_mask
    feature_segment_ids[ex_index] = feature.segment_ids
    label_ids[ex_index] = feature.label_id
    for ex_cnt in range(use_extra):
      feature_extra_ids[ex_cnt][ex_index] = feature.extra_ids[ex_cnt]

  return feature_input_ids, feature_input_mask, feature_segment_ids, label_ids, feature_extra_ids


def file_based_input_fn_builder(input_file, seq_length, is_training,
                                drop_remainder):
  """Creates an `input_fn` closure to be passed to TPUEstimator."""

  name_to_features = {
      "input_ids": tf.FixedLenFeature([seq_length], tf.int64),
      "input_mask": tf.FixedLenFeature([seq_length], tf.int64),
      "segment_ids": tf.FixedLenFeature([seq_length], tf.int64),
      "label_ids": tf.FixedLenFeature([], tf.int64),
  }

  def _decode_record(record, name_to_features):
    """Decodes a record to a TensorFlow example."""
    example = tf.parse_single_example(record, name_to_features)

    # tf.Example only supports tf.int64, but the TPU only supports tf.int32.
    # So cast all int64 to int32.
    for name in list(example.keys()):
      t = example[name]
      if t.dtype == tf.int64:
        t = tf.to_int32(t)
      example[name] = t

    return example

  def input_fn(params):
    """The actual input function."""
    batch_size = params["batch_size"]

    # For training, we want a lot of parallel reading and shuffling.
    # For eval, we want no shuffling and parallel reading doesn't matter.
    d = tf.data.TFRecordDataset(input_file)
    if is_training:
      d = d.repeat()
      d = d.shuffle(buffer_size=100)

    d = d.apply(
        tf.contrib.data.map_and_batch(
            lambda record: _decode_record(record, name_to_features),
            batch_size=batch_size,
            drop_remainder=drop_remainder))

    return d

  return input_fn


def _truncate_seq_pair(tokens_a, tokens_b, max_length):
  """Truncates a sequence pair in place to the maximum length."""

  # This is a simple heuristic which will always truncate the longer sequence
  # one token at a time. This makes more sense than truncating an equal percent
  # of tokens from each, since if one sequence is very short then each token
  # that's truncated likely contains more information than a longer sequence.
  while True:
    total_length = len(tokens_a) + len(tokens_b)
    if total_length <= max_length:
      break
    if len(tokens_a) > len(tokens_b):
      tokens_a.pop()
    else:
      tokens_b.pop()


def get_dense_out_res(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """get multi output from a FNN"""
    dense_tensor = in_tensor
    outs = []
    for i in range(loss_num):
        dense_tensor = tf.layers.dropout(
            dense_tensor, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor1 = tf.layers.dense(
            dense_tensor, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor1 = tf.layers.dropout(
            dense_tensor1, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor2 = tf.layers.dense(
            dense_tensor1, 
            hidden_size//4,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor2 = tf.layers.dropout(
            dense_tensor2, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor3 = tf.layers.dense(
            dense_tensor2, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor = dense_tensor3 + dense_tensor
        out_tensor = tf.layers.dense(
        dense_tensor, 
        2,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        outs.append(out_tensor)
    return outs

def get_multitasks_out(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """get multi output from a multi-tasks"""
    dense_tensor = in_tensor
    outs = []
    for i in range(loss_num):
        dense_tensor = tf.layers.dropout(
            in_tensor, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor1 = tf.layers.dense(
            dense_tensor, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor1 = tf.layers.dropout(
            dense_tensor1, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor2 = tf.layers.dense(
            dense_tensor1, 
            hidden_size//4,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor2 = tf.layers.dropout(
            dense_tensor2, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor3 = tf.layers.dense(
            dense_tensor2, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        out_tensor = tf.layers.dense(
        dense_tensor3, 
        2,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        outs.append(out_tensor)
    return outs



def get_dense_out(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """get multi output from a FNN"""
    dense_tensor = in_tensor
    outs = []
    for i in range(loss_num):
        dense_tensor = tf.layers.dropout(
            dense_tensor, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor1 = tf.layers.dense(
            dense_tensor, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor1 = tf.layers.dropout(
            dense_tensor1, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor2 = tf.layers.dense(
            dense_tensor1, 
            hidden_size//4,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor2 = tf.layers.dropout(
            dense_tensor2, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor = tf.layers.dense(
            dense_tensor2, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        out_tensor = tf.layers.dense(
        dense_tensor, 
        2,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        outs.append(out_tensor)
    return outs


def get_rnn_out(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """get multi output from a FNN"""
    gru1 = tf.keras.layers.GRUCell(hidden_size)
    gru2 = tf.keras.layers.GRUCell(hidden_size//4)
    gru3 = tf.keras.layers.GRUCell(hidden_size)
    gru4 = tf.keras.layers.GRUCell(2)
    grus = [gru1, gru2, gru3, gru4]
    rnn = tf.keras.layers.RNN(grus, return_sequences=True, return_state=False)
    dense_tensor = in_tensor
    dense_tensor = tf.expand_dims(dense_tensor, axis=1)
    dense_tensor = tf.tile(dense_tensor, [1, loss_num, 1])
    out_tensors = rnn(dense_tensor)
    outs = []
    for i in range(loss_num):
        outs.append(out_tensors[:,i,:])
    return outs


def get_multi_layer_loss(labels, out_tensors, num_labels=5, loss_weights=None):
    """
    """
    oh_labels = tf.one_hot(labels, 6)
    ones = tf.ones_like(oh_labels[:,0:2])
    zeros = tf.zeros_like(oh_labels[:,0:2])
    losses = []
    bias_ = 1
    for i in range(1, num_labels):
      if i == 3:
        continue
      if i > 3:
        bias_ = 2
      pos_col_ = tf.reduce_sum(oh_labels[:,i:], axis=-1, keep_dims=True)
      neg_col = tf.reduce_sum(oh_labels[:,0:i], axis=-1, keep_dims=True)
      bin_label = tf.concat([neg_col, pos_col_], axis=-1)
      # bin_label = tf.where(two_col>=i, ones, zeros, name='prop_label{}'.format(i))
      log_probs = tf.nn.log_softmax(out_tensors[i-bias_], axis=-1)
      per_example_loss = -tf.reduce_sum(bin_label * log_probs, axis=-1)
      loss = tf.reduce_mean(per_example_loss)
      losses.append(loss)
    out_loss = 0
    for i, ls in enumerate(losses):
        out_loss = out_loss + ls * loss_weights[i]
    return out_loss


def create_model(bert_config, is_training, input_ids, input_mask, segment_ids,
                 labels, num_labels, use_one_hot_embeddings, extra_ids):
  """Creates a classification model."""
  model = modeling.BertModel(
      config=bert_config,
      is_training=is_training,
      input_ids=input_ids,
      input_mask=input_mask,
      token_type_ids=segment_ids,
      use_one_hot_embeddings=use_one_hot_embeddings,
      use_extra=bert_config.use_extra,
      extra_ids=extra_ids
      )

  # In the demo, we are doing a simple classification task on the entire
  # segment.
  #
  # If you want to use the token-level output, use model.get_sequence_output()
  # instead.
  output_layer = model.get_pooled_output()

  # one_hot_labels = tf.one_hot(labels, depth=num_labels, dtype=tf.float32)
  # output_layer,one_hot_labels = self.mixup(output_layer,one_hot_labels,1.0)

  out_tensors = get_rnn_out(output_layer, bert_config.hidden_size, bert_config.loss_num,bert_config.out_dense_drop, is_training)
  # out_tensors = get_multitasks_out(output_layer, bert_config.hidden_size, bert_config.loss_num,bert_config.out_dense_drop, is_training)
  # out_tensors = get_dense_out(output_layer, bert_config.hidden_size, bert_config.loss_num,bert_config.out_dense_drop, is_training)
  probabilities = []
  for out_ts in out_tensors:
    logits = out_ts
    prob = tf.nn.softmax(logits, axis=-1)
    probabilities.append(prob)
  loss = get_multi_layer_loss(labels, out_tensors, num_labels, bert_config.loss_weights)

  return (loss, probabilities, model.sequence_output)


def convert_labels(labels, max_idx=5):
  '''
  convert 0,1,2,4,5 into special one-hot form 
  '''
  bs = labels.shape[0]
  true_labels = np.zeros([bs, max_idx+1])
  for i, lbl in enumerate(labels):
    if lbl == 0:
      true_labels[i, 0] = 1
      true_labels[i, 1:] = 0
    else:
      true_labels[i, 1:lbl+1] = 1
  return true_labels


def mixup(self, x, l, beta):
      mix = tf.distributions.Beta(beta, beta).sample([tf.shape(x)[0], 1])
      mix = tf.maximum(mix, 1 - mix)
      size1 = x.shape[1]
      size2 = x.shape[2]
      x1 = tf.reshape(x, [-1, size1*size2])
      xmix = x1 * mix + x1[::-1] * (1 - mix)
      xmix = tf.reshape(xmix, [-1, size1, size2])
      lmix = l * mix + l[::-1] * (1 - mix)
      return xmix, lmix
      
class DataIter(object):

  def __init__(self, data, batch_size, seed=1337, use_extra=0):
    """加载分类数据
    Args:
      data: tuple
      batch_size: int, batch size
      seed: int or None, if int, used for shuffle data
    """
    self.data = data[:]
    self._batch_size = batch_size
    self._seed = seed
    self.input_ids = self.data[0]
    self._data_count = self.input_ids.shape[0]
    self._iter_variable = 0
    self._data_ids = np.array(range(self._data_count))
    self.use_extra = use_extra

    # batch count
    self._batch_count = int(math.ceil(self._data_count/self._batch_size))

  def shuffle(self):
    """shuffle data"""
    if isinstance(self._seed, int):
      random.seed(self._seed)
    random.shuffle(self._data_ids)

  def _generate_batch(self, start, end):
    """generate batch
    Args:
      start: int, start data id
      end: int, end data id

    Returns:
      data_dict: dict({'source': np.array, 'target': np.array})

    labels:
      ["上网慢", "产品介绍", "产品介绍（腾讯王卡）", "产品信息", "信号弱不稳定",
       "其他使用信息查询", "历史话费", "取消低消送流量", "取消增值业务", "合约查询",
       "固话宽带移机", "国际漫游", "增值费疑问", "套餐余量", "套餐资费",
       "宽带密码修改重置", "已定业务", "应交话费", "当前话费", "手机上网流量",
       "手机客户密码修改获取", "报障转四话", "无办理意向不需要仅咨询", "无法上网",
       "无法打开网页", "无法拨打接听电话", "查询停机原因", "查询宽带账号",
       "流量月包-取消", "流量疑问", "短期促销类流量包-开通", "话费余额（欠费）",
       "送流量", "销户退网含预约拆机", "错误678815651", "障碍催修", "非联通业务咨询"]
    """
    batch_indices = []
    for idx in range(start, end, 1):
      data_id = self._data_ids[idx]
      batch_indices.append(data_id)
    batch_indices = np.array(batch_indices)
    # print(batch_indices)
    # print(self.input_ids[:3])
    # print(self.input_mask[:3])
    # print(self.segment_ids[:3])
    # print(self.label_ids[:3])
    # exit()
    out_tensor = []
    for i, tensor in enumerate(self.data[0:-1]):
      out_tensor.append(self.data[i][batch_indices])
    if self.use_extra:
      last_ts = []
      for extra_cnt in range(self.use_extra):
        last_ts.append(self.data[-1][extra_cnt][batch_indices])
      out_tensor.append(last_ts)

    return out_tensor

  def __len__(self):
    raise self._data_count

  def __iter__(self):
    self._iter_variable = 0
    return self

  def __next__(self):
    start = self._iter_variable
    end = self._iter_variable + self._batch_size
    if end > self._data_count:
      end = self._data_count
    if self._iter_variable > self._data_count or start >= end:
      self.shuffle()
      raise StopIteration()
    self._iter_variable = end
    return self._generate_batch(start, end)

  next = __next__  # Python 2

  @property
  def batch_count(self):
    return self._batch_count

  @property
  def batch_size(self):
    return self._batch_size

  @property
  def data_count(self):
    return self._data_count


class ModelBuilder:

  def __init__(self, bert_config, num_labels, max_seq_length, init_checkpoint,
               learning_rate, num_train_steps, num_warmup_steps, use_tpu,
               use_one_hot_embeddings, nb_epoch, max_patience, check_freq,
               path_model):
    self._bert_config = bert_config
    self._num_labels = num_labels
    self._max_seq_length = max_seq_length
    self._init_checkpoint = init_checkpoint
    self._learning_rate = learning_rate
    self._num_train_steps = num_train_steps
    self._num_warmup_steps = num_warmup_steps
    self._use_tpu = use_tpu
    self._use_one_hot_embeddings = use_one_hot_embeddings
    self._nb_epoch = nb_epoch
    self._max_patience = max_patience
    self._check_freq = check_freq
    self._path_model = path_model

  def builde_model(self, mode='train'):
    self.input_ids_ph = tf.placeholder(
      tf.int32, shape=(None, self._max_seq_length), name='input_ids_ph')
    self.input_mask_ph = tf.placeholder(
      tf.int32, shape=(None, self._max_seq_length), name='input_mask_ph')
    self.segment_ids_ph = tf.placeholder(
      tf.int32, shape=(None, self._max_seq_length), name='segment_ids_ph')
    self.label_ids_ph = tf.placeholder(tf.int32, shape=(None,), name='label_ph')
    self.is_training = tf.placeholder(tf.bool, name='is_training')
    if self._bert_config.use_extra:
      self.extra_ids_ph = []
      for extra_cnt in range(self._bert_config.use_extra):
        self.extra_ids_ph.append(tf.placeholder(tf.int32, shape=(None, self._max_seq_length), name='extra_ids_ph{}'.format(extra_cnt)))
    else:
      self.extra_ids_ph = None

    (self.total_loss, self.probabilities, self.debug_output) = \
      create_model(
        self._bert_config, self.is_training, self.input_ids_ph,
        self.input_mask_ph, self.segment_ids_ph, self.label_ids_ph,
        self._num_labels, self._use_one_hot_embeddings, self.extra_ids_ph)

    self._topk_labels = []
    for prob in self.probabilities:
      _, k_idx = tf.nn.top_k(prob, k=1)
      self._topk_labels.append(k_idx)

    self.normal_loss = self.total_loss

    # # entropy loss
    # p_log = tf.log(self.probabilities + 1e-8)
    # entropy = tf.reduce_mean(
    #   tf.reduce_sum(-self.probabilities * p_log, axis=-1), axis=-1)
    # beta = 0.01
    # self.total_loss -= beta * entropy

    tvars = tf.trainable_variables()

    scaffold_fn = None
    initialized_variable_names = None
    if self._init_checkpoint:
      tf.logging.info('init model from {0}'.format(self._init_checkpoint))
      (assignment_map, initialized_variable_names
      ) = modeling.get_assignment_map_from_checkpoint(
        tvars, self._init_checkpoint)

      tf.train.init_from_checkpoint(self._init_checkpoint, assignment_map)

    tf.logging.info("**** Trainable Variables ****")
    for var in tvars:
      init_string = ""
      if self._init_checkpoint and var.name in initialized_variable_names:
        init_string = ", *INIT_FROM_CKPT*"
      tf.logging.info("  name = %s, shape = %s%s", var.name, var.shape,
                      init_string)

    if mode == 'train':
      self.train_op = optimization.create_optimizer(
        self.total_loss, self._learning_rate, self._num_train_steps,
        self._num_warmup_steps, self._use_tpu)
      # self.train_op = optimization.create_optimizer(
      #   self.total_loss, self._learning_rate)

    gpu_options = tf.GPUOptions(allow_growth=True)
    self._sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
    init = tf.global_variables_initializer()
    self._sess.run(init)

    self._model_saver = tf.train.Saver(max_to_keep=100)
    if mode != 'train':
      self._restore_model()

  def _restore_model(self):
    self._model_saver.restore(self._sess, self._path_model)

  def _save_model(self, dev_loss, best_dev_loss, current_patience,num_model):
    """保存模型
    Args:
      dev loss: float
      best_dev_loss: float
      current_patience: int

    Returns:
      finished: boolean
      best_dev_loss: float
      current_patience: int
    """
    finished = False
    # save model
    if dev_loss < best_dev_loss:
      current_patience = 0
      best_dev_loss = 1.e8
      # save model
      self._model_saver.save(self._sess, self._path_model+str(num_model))
      tf.logging.info('model has saved to {0}!'.format(self._path_model+str(num_model)))
      finished = False
    else:
      current_patience += 1
      tf.logging.info('no improvement, current patience: {0} / {1}'.format(
        current_patience, self._max_patience))
      if current_patience >= self._max_patience:
        tf.logging.info(
          'finished training! (early stopping, max patience: {0})'.format(
            self._max_patience))
        finished = True

    return finished, best_dev_loss, current_patience

  def _save_model_acc(self, dev_acc, best_dev_acc, current_patience):
    """保存模型(根据dev acc)
    Args:
      dev acc: float
      best_dev_acc float
      current_patience: int

    Returns:
      finished: boolean
      best_dev_loss: float
      current_patience: int
    """
    finished = False
    # save model
    if dev_acc > best_dev_acc:
      current_patience = 0
      best_dev_acc = dev_acc
      # save model
      self._model_saver.save(self._sess, self._path_model)
      tf.logging.info('model has saved to {0}!'.format(self._path_model))
      finished = False
    else:
      current_patience += 1
      tf.logging.info('no improvement, current patience: {0} / {1}'.format(
        current_patience, self._max_patience))
      if current_patience >= self._max_patience:
        tf.logging.info(
          'finished training! (early stopping, max patience: {0})'.format(
            self._max_patience))
        finished = True

    return finished, best_dev_acc, current_patience

  def get_feed_dict(self, inputs, is_training=True):
    feed_dict = {}
    # input_ids, input_mask, segment_ids, label_ids, extra_ids_ph = inputs[:]
    feed_dict[self.input_ids_ph] = inputs[0]
    feed_dict[self.input_mask_ph] = inputs[1]
    feed_dict[self.segment_ids_ph] = inputs[2]
    feed_dict[self.label_ids_ph] = inputs[3]
    feed_dict[self.is_training] = is_training
    if self.extra_ids_ph:
      for i, extra in enumerate(self.extra_ids_ph):
        feed_dict[extra] = inputs[-1][i]
    return feed_dict

  def train(self, data_iter_train, data_iter_valid):
    best_dev_loss = 1.e8
    best_dev_acc = -1
    current_patience = 0
    batch_count, instance_count = 0, 0
    train_loss = 0.
    log_writer = codecs.open(
      './qa_4k_acc_loss.txt', 'w', encoding='utf-8')
    num_model = 0
    for epoch in range(int(self._nb_epoch)):
      tf.logging.info('epoch {0} / {1} / {2}'.format(epoch+1, self._nb_epoch,time.asctime(time.localtime(time.time()))))
      # train
      for i, inputs in enumerate(data_iter_train):
        feed_dict = self.get_feed_dict(inputs, is_training=True)
        loss, _ = self._sess.run(
          [self.total_loss, self.train_op], feed_dict=feed_dict)
        train_loss += loss
        batch_count += 1
        instance_count += inputs[0].shape[0]

        if batch_count % self._check_freq != 0:
          continue

        train_loss /= self._check_freq

        tf.logging.info('batch_count: {0}, instance count: {1}'.format(
          batch_count, instance_count))
        # print('loss', train_loss)

        # evaluate
        dev_loss, dev_loss = 0., 0.
        label_ids_test, label_ids_gold = [], []
        label_ids_prob, label_ids_test, dev_acc, auc_num, precis, recall, f1_score = [], [], [], [], [], [], []
        prob_num = len(self.probabilities)
        for prob_cnt in range(prob_num):
          label_ids_prob.append([])
          label_ids_test.append([])
          dev_acc.append([])
          auc_num.append([])
          precis.append([])
          recall.append([])
          f1_score.append([])
        for i, inputs in enumerate(data_iter_valid):
          feed_dict = self.get_feed_dict(inputs, is_training=False)
          out_ts = [self.normal_loss]
          out_ts.extend(self.probabilities)
          loss_probs = self._sess.run(
            out_ts, feed_dict=feed_dict)
          loss = loss_probs[0]
          for prob_cnt, probabilities in enumerate(loss_probs[1:]):
            label_ids_prob[prob_cnt].append(probabilities[:,1])
            label_ids_test[prob_cnt].append(np.argmax(probabilities, axis=-1))
          label_ids_gold.append(inputs[-1-self._bert_config.use_extra])
          dev_loss += loss
        dev_loss /= data_iter_valid.batch_count
        label_ids_gold = np.concatenate(label_ids_gold)
        label_ids_gold = convert_labels(label_ids_gold)
        bias = 1
        for prob_cnt in range(prob_num):
          if prob_cnt == 2:
            bias = 2
          # something wrong here
          label_ids_test[prob_cnt] = np.concatenate(label_ids_test[prob_cnt])
          label_ids_prob[prob_cnt] = np.concatenate(label_ids_prob[prob_cnt])
          auc_num[prob_cnt] = roc_auc_score(label_ids_gold[:,prob_cnt+bias], label_ids_prob[prob_cnt])
          precis[prob_cnt] = metrics.precision_score(label_ids_gold[:,prob_cnt+bias],label_ids_test[prob_cnt])
          recall[prob_cnt] = metrics.recall_score(label_ids_gold[:,prob_cnt+bias],label_ids_test[prob_cnt])
          f1_score[prob_cnt] = metrics.f1_score(label_ids_gold[:,prob_cnt+bias],label_ids_test[prob_cnt])

          # accuracy = metrics.accuracy_score(label_ids_gold,label_ids_test, average='weighted', labels=np.unique(label_ids_test))
          # compute acc
          dev_acc[prob_cnt] = sum((label_ids_gold[:,prob_cnt+bias]==label_ids_test[prob_cnt]).astype(np.int32)) \
                / label_ids_gold[:,prob_cnt+bias].shape[0]

        log_writer.write('{0}\t{1}\n'.format(dev_acc, dev_loss))

        tf.logging.info(
          'train loss: {}, valid loss: {}, valid acc: {}, valid auc: {}, valid precis: {}, valid recall:{}, valid f1:{}'.format(
          train_loss, dev_loss, dev_acc, auc_num,precis,recall,f1_score))

        train_loss = 0.

        if batch_count % (5*self._check_freq) != 0:
            continue
        # save model
        finished, best_dev_loss, current_patience = self._save_model(
        dev_loss, best_dev_loss, current_patience,num_model)
        # finished, best_dev_acc, current_patience = self._save_model_acc(
        #   dev_acc, best_dev_acc, current_patience)
        num_model += 1
        if finished:
          return

    tf.logging.info('finished training!')

  def predict(self, data_iter):
    instance_count = 0
    label_ids = []
    # predict_label_ids_topk = []
    label_ids_test, label_ids_gold = [], []
    probability_list = []
    top_k_right_count = []
    out_ts = []
    out_ts.extend(self.probabilities)
    out_ts.extend(self._topk_labels)
    out_ts.append(self.debug_output)
    probabilities = []
    prob_num = (len(out_ts)-1)//2
    test_acc = []
    test_acc_topk = []
    # topk_label_ids = []
    for prob_cnt in range(prob_num):
      probabilities.append([])
      # topk_label_ids.append([])
      # predict_label_ids_topk.append([])
      label_ids_test.append([])
      probability_list.append([])
      test_acc.append([])
      test_acc_topk.append([])
      # top_k_right_count.append([])
    for i, inputs in enumerate(data_iter):
      feed_dict = self.get_feed_dict(inputs, is_training=False)
      out_var = self._sess.run(
        out_ts, feed_dict=feed_dict)
      # debug_output = out_var[-1]
      probabilities, topk_label_ids = out_var[0:prob_num], out_var[prob_num:-1]
      label_ids = inputs[-1-self._bert_config.use_extra]
      for prob_cnt in range(prob_num):
        # for j, idx_list in enumerate(topk_label_ids[prob_cnt]):
        #   temp = []
        #   for idx in idx_list:
        #     temp.append(idx)
        #   predict_label_ids_topk[prob_cnt].append(temp)
        #   if label_ids[j] in temp:
        #     top_k_right_count[prob_cnt] += 1

        # for i in range(probabilities.shape[0]):
        #   print(i+1, probabilities[i])
        # # print(debug_output[0])
        # exit()
        # probabilities_all.append(probabilities)
        label_ids_test[prob_cnt].append(np.argmax(probabilities[prob_cnt], axis=-1))
        probability_list[prob_cnt].append(probabilities[prob_cnt])
      label_ids_gold.append(inputs[-1-self._bert_config.use_extra])
      instance_count += inputs[0].shape[0]
    label_ids_gold = np.concatenate(label_ids_gold)
    label_ids_gold = convert_labels(label_ids_gold)
    bias = 1
    for prob_cnt in range(prob_num):
      if prob_cnt>=2:
        bias = 2
      label_ids_test[prob_cnt] = np.concatenate(label_ids_test[prob_cnt])
      test_acc[prob_cnt] = sum((label_ids_gold[:,prob_cnt+bias] == label_ids_test[prob_cnt]).astype(np.int32)) \
                / label_ids_gold.shape[0]
      # test_acc_topk[prob_cnt] = top_k_right_count[prob_cnt] / label_ids_gold[:,prob_cnt+bias].shape[0]
    print('instance_count: {0}, acc: {1}'.format(
      instance_count, test_acc)) # , top-3 acc: {2} , test_acc_topk
    tf.logging.info('finished!')

    for prob_cnt in range(prob_num):
      # probability
      probability_list[prob_cnt] = np.concatenate(probability_list[prob_cnt], axis=0)
      path_test_result = os.path.join(FLAGS.result_dir, 'test.prob_{}.result'.format(prob_cnt))
      w_f = open(path_test_result,'w',encoding='utf-8')
      w_f.close()
      np.savetxt(path_test_result, probability_list[prob_cnt])
      print('result has wrote into: {0}'.format(path_test_result))
    return label_ids_test, probability_list # , predict_label_ids_topk

  @property
  def count_param(self):
    '''
    计算模型参数量
    '''
    # 定义总参数量、可训练侧数量及非可训练参数量变量
    Total_params = 0
    Trainable_params = 0
    NonTrainable_params = 0

    # 遍历tf.global_variables()返回的全局变量列表
    for var in tf.global_variables():
        shape = var.shape # 获取每个变量的shape，其类型为'tensorflow.python.framework.tensor_shape.TensorShape'
        array = np.asarray([dim.value for dim in shape]) # 转换为numpy数组，方便后续计算
        mulValue = np.prod(array) # 使用numpy prod接口计算数组所有元素之积

        Total_params += mulValue # 总参数量
        if var.trainable:
            Trainable_params += mulValue # 可训练参数量
        else:
            NonTrainable_params += mulValue # 非可训练参数量

    print('Total params: {}'.format(Total_params))
    print('Trainable params: {}'.format(Trainable_params))
    print('Non-trainable params: {}'.format(NonTrainable_params))
    return Total_params, Trainable_params, NonTrainable_params

def main(_):
  tf.logging.set_verbosity(tf.logging.INFO)

  processors = {
      "call": CallProcessor,
      "sentiment": SentimentProcessor,
  }

  if not FLAGS.do_train and not FLAGS.do_eval and not FLAGS.do_predict:
    raise ValueError(
        "At least one of `do_train`, `do_eval` or `do_predict' must be True.")

  bert_config = modeling.BertConfig.from_json_file(FLAGS.bert_config_file)

  if FLAGS.max_seq_length > bert_config.max_position_embeddings:
    raise ValueError(
        "Cannot use sequence length %d because the BERT model "
        "was only trained up to sequence length %d" %
        (FLAGS.max_seq_length, bert_config.max_position_embeddings))

  tf.gfile.MakeDirs(FLAGS.output_dir)
  tf.gfile.MakeDirs(FLAGS.result_dir)

  task_name = FLAGS.task_name.lower()

  if task_name not in processors:
    raise ValueError("Task not found: %s" % (task_name))

  processor = processors[task_name]()

  label_list = processor.get_labels()

  tokenizer = tokenization.FullTokenizer(
      vocab_file=FLAGS.vocab_file, do_lower_case=FLAGS.do_lower_case)
  train_examples = None
  eval_examples = None
  num_train_steps = None
  num_warmup_steps = None
  if FLAGS.do_train:
    train_examples = processor.get_train_examples(FLAGS.data_dir)
    num_train_steps = int(
        len(train_examples) / FLAGS.train_batch_size * FLAGS.num_train_epochs)
    num_warmup_steps = int(num_train_steps * FLAGS.warmup_proportion)
    eval_examples = processor.get_dev_examples(FLAGS.data_dir)

  model_helper = ModelBuilder(
    bert_config=bert_config,
    num_labels=len(label_list),
    init_checkpoint=FLAGS.init_checkpoint,
    learning_rate=FLAGS.learning_rate,
    num_train_steps=num_train_steps,
    num_warmup_steps=num_warmup_steps,
    use_tpu=FLAGS.use_tpu,
    use_one_hot_embeddings=FLAGS.use_tpu,
    max_seq_length=FLAGS.max_seq_length,
    nb_epoch=FLAGS.num_train_epochs,
    path_model=os.path.join(FLAGS.output_dir, 'best_model{}'.format(load_model_idx)),
    check_freq=FLAGS.check_freq, max_patience=1000)

  if FLAGS.do_train:
    # train dataset
    train_input_ids, train_input_mask, train_segment_ids, train_label_ids, train_extra_ids = \
      convert_examples_to_features(
        train_examples, label_list, FLAGS.max_seq_length, tokenizer, bert_config.use_extra)
    data_iter_train = DataIter(
      (train_input_ids, train_input_mask, train_segment_ids, train_label_ids, train_extra_ids),
      batch_size=FLAGS.train_batch_size, seed=1337, use_extra=bert_config.use_extra)
    # valid dataset
    dev_input_ids, dev_input_mask, dev_segment_ids, dev_ids, dev_extra_ids = \
      convert_examples_to_features(
        eval_examples, label_list, FLAGS.max_seq_length, tokenizer, bert_config.use_extra)
    data_iter_valid = DataIter(
      (dev_input_ids, dev_input_mask, dev_segment_ids, dev_ids, dev_extra_ids),
      batch_size=FLAGS.eval_batch_size, seed=1337, use_extra=bert_config.use_extra)
    tf.logging.info("***** Running training *****")
    tf.logging.info("  Num examples = %d", len(train_examples))
    tf.logging.info("  Batch size = %d", FLAGS.train_batch_size)
    tf.logging.info("  Num steps = %d", num_train_steps)
    # train
    model_helper.builde_model(mode='train')
    print(model_helper.count_param)

    model_helper.train(data_iter_train, data_iter_valid)

  if FLAGS.do_predict:
    if not FLAGS.do_train:
      model_helper.builde_model(mode='test')
      print(model_helper.count_param)

    predict_examples = processor.get_test_examples(FLAGS.data_dir)
    test_input_ids, test_input_mask, test_segment_ids, test_ids, test_extra_ids = \
      convert_examples_to_features(
        predict_examples, label_list, FLAGS.max_seq_length,
        tokenizer, bert_config.use_extra)
    data_iter_test = DataIter(
      (test_input_ids, test_input_mask, test_segment_ids, test_ids, test_extra_ids),
      batch_size=FLAGS.predict_batch_size, use_extra=bert_config.use_extra)

    tf.logging.info("***** Running prediction*****")
    tf.logging.info("  Num examples = %d", len(predict_examples))
    tf.logging.info("  Batch size = %d", FLAGS.predict_batch_size)
    # (test_count, nb_classes) , predict_label_ids_topk
    test_label_ids, probabilities = \
      model_helper.predict(data_iter_test)

    for prob_cnt in range(len(test_label_ids)):
      predict_file = os.path.join(FLAGS.result_dir, "test_results_{}.txt".format(prob_cnt))
      with codecs.open(predict_file, 'w', encoding='utf-8') as file_result:
        for label_id in test_label_ids[prob_cnt]:
          file_result.write('{0}\n'.format(label_list[label_id]))

      # data_count = probabilities[prob_cnt].shape[0]
      # predict_file = os.path.join(FLAGS.result_dir, "test_results_{}.prob.txt".format(prob_cnt))
      # with codecs.open(predict_file, 'w', encoding='utf-8') as file_result:
      #   for i in range(data_count):
      #     label_ids = np.argsort(probabilities[prob_cnt][i]).reshape(-1)[::-1]
      #     temp = []
      #     for idx in label_ids:
      #       temp.append(CallProcessor.get_labels()[idx])
      #     file_result.write('{0}\n'.format(' '.join(temp[:3])))


if __name__ == "__main__":
  flags.mark_flag_as_required("data_dir")
  flags.mark_flag_as_required("task_name")
  flags.mark_flag_as_required("vocab_file")
  flags.mark_flag_as_required("bert_config_file")
  flags.mark_flag_as_required("output_dir")
  tf.app.run()
