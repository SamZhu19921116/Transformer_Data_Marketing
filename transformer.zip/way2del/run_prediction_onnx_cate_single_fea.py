#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

import sys
import imp
imp.reload(sys)
import os 
import glob
os.environ["CUDA_VISIBLE_DEVICES"]='3'
import dataconstructor as dconstr
import tokenization
import dataprovider as dprovid
import tensorflow as tf
from tensorflow.python.platform import gfile
import numpy as np
import time
sys.path.append('../data_analysis/')
import app2_360cate as a2c 


app_dict = a2c.load_cate_table('../data_analysis/360spiderlabel.txt')
simple_id_dict = a2c.cate_id2simple_id(app_dict)
app_cate_dict  = a2c.get_simple_idx(app_dict, simple_id_dict)
# print(app_cate_dict['07BABY'])

def data_processer(line):
    items = line.strip().split('\t')
    ident = items[0]
    is_jump = False
    # print(len(items))
    if len(items)<2:
        items.append('')
    # tmp = items[1]
    tmp = ','.join(items[1:-2])
    result = tmp.replace(',null', '').replace('null,', '')
    # result = tmp
    # print(result)
    return ident, result, is_jump


def lines2TransformerExample(line, guid, no_label=False):
    if len(line) == 1:
        text_a = "[PAD]"
    else:
        text_a = tokenization.convert_to_unicode(line[1])
    if not no_label:
        label = tokenization.convert_to_unicode(line[0])
    else:
        label = line[0]
    return dconstr.TransformerInputExample(guid=guid, text_a=text_a, text_b=None, label=label)


def _truncate_seq_pair(tokens_a, tokens_b, max_length):
  """Truncates a sequence pair in place to the maximum length."""

  # This is a simple heuristic which will always truncate the longer sequence
  # one token at a time. This makes more sense than truncating an equal percent
  # of tokens from each, since if one sequence is very short then each token
  # that's truncated likely contains more information than a longer sequence.
  while True:
    total_length = len(tokens_a) + len(tokens_b)
    if total_length <= max_length:
      break
    if len(tokens_a) > len(tokens_b):
      tokens_a.pop()
    else:
      tokens_b.pop()
     

def convert_single_example(example, label_list, max_seq_length,
                           tokenizer, no_label=False):
  """Converts a single `InputExample` into a single `InputFeatures`."""
  if not no_label:
    label_map = {}
    for (i, label) in enumerate(label_list):
        label_map[label.lower()] = i

  # 替换中文数字和纯字母
  # text_a = ' '.join([replace_num(word) for word in example.text_a.split()])
  text_a = ' '.join([word for word in example.text_a.split()])
  # tokens_a = tokenizer.tokenize(text_a)
  tokens_a = list(text_a.split(','))
  tokens_b = None
  if example.text_b:
    tokens_b = tokenizer.tokenize(example.text_b)

  if tokens_b:
    # Modifies `tokens_a` and `tokens_b` in place so that the total
    # length is less than the specified length.
    # Account for [CLS], [SEP], [SEP] with "- 3"
    _truncate_seq_pair(tokens_a, tokens_b, max_seq_length - 3)
  else:
    # Account for [CLS] and [SEP] with "- 2"
    if len(tokens_a) > max_seq_length - 2:
      tokens_a = tokens_a[0:(max_seq_length - 2)]

  # The convention in BERT is:
  # (a) For sequence pairs:
  #  tokens:   [CLS] is this jack ##son ##ville ? [SEP] no it is not . [SEP]
  #  type_ids: 0     0  0    0    0     0       0 0     1  1  1  1   1 1
  # (b) For single sequences:
  #  tokens:   [CLS] the dog is hairy . [SEP]
  #  type_ids: 0     0   0   0  0     0 0
  #
  # Where "type_ids" are used to indicate whether this is the first
  # sequence or the second sequence. The embedding vectors for `type=0` and
  # `type=1` were learned during pre-training and are added to the wordpiece
  # embedding vector (and position vector). This is not *strictly* necessary
  # since the [SEP] token unambiguously separates the sequences, but it makes
  # it easier for the model to learn the concept of sequences.
  #
  # For classification tasks, the first vector (corresponding to [CLS]) is
  # used as as the "sentence vector". Note that this only makes sense because
  # the entire model is fine-tuned.
  tokens = []
  segment_ids = []
  tokens.append("[CLS]")
  segment_ids.append([0]*max_type_length)
  for token in tokens_a:
    # ex_token = token.split(':')
    # token = ex_token[0]
    tokens.append(token)
    if token in app_cate_dict:
      cate_ids = app_cate_dict[token]
    else:
      cate_ids = [0]
    cate_ids_len = len(cate_ids)
    if cate_ids_len < max_type_length:
      cate_ids.extend([0]*(max_type_length-cate_ids_len))
    elif cate_ids_len > max_type_length:
      cate_ids = cate_ids[0:max_type_length]
    segment_ids.append(cate_ids)
  tokens.append("[SEP]")
  segment_ids.append([0]*max_type_length)

  input_ids = tokenizer.convert_tokens_to_ids(tokens)

  # The mask has 1 for real tokens and 0 for padding tokens. Only real
  # tokens are attended to.
  input_mask = [1] * len(input_ids)

  # Zero-pad up to the sequence length.
  while len(input_ids) < max_seq_length:
    input_ids.append(0)
    input_mask.append(0)
    segment_ids.append([0]*max_type_length)

  assert len(input_ids) == max_seq_length
  assert len(input_mask) == max_seq_length
  assert len(segment_ids) == max_seq_length

  if not no_label:
    if example.label.lower() not in label_map:
        label_id = label_map['ERROR'.lower()]
    else:
        label_id = label_map[example.label.lower()]
  else:
    label_id = example.label

  feature = dconstr.TransformerInputFeatures(
      input_ids=input_ids,
      input_mask=input_mask,
      segment_ids=segment_ids,
      label_id=label_id)
  return feature


def convert_examples_to_features(
    examples, label_list, max_seq_length, tokenizer, no_label=False):
  """Convert a set of `InputExample`s to a TFRecord file."""

  data_count = len(examples)
  feature_input_ids = np.zeros(
    shape=(data_count, max_seq_length), dtype='int32')
  feature_input_mask = np.zeros(
    shape=(data_count, max_seq_length), dtype='int32')
  feature_segment_ids = np.zeros(
    shape=(data_count, max_type_length, max_seq_length), dtype='int32')
  if not no_label:
    label_ids = np.zeros(shape=(data_count,), dtype='int32')
  else:
    label_ids = np.empty(shape=(data_count,), dtype=object)
  for (ex_index, example) in enumerate(examples):
    feature = convert_single_example(example, label_list,
                                     max_seq_length, tokenizer, no_label)
    feature_input_ids[ex_index] = feature.input_ids
    feature_input_mask[ex_index] = feature.input_mask
    segment_ids = np.transpose(np.array(feature.segment_ids))
    feature_segment_ids[ex_index] = segment_ids
    label_ids[ex_index] = feature.label_id

  return feature_input_ids, feature_input_mask, feature_segment_ids, label_ids


def get_feed_dict(inputs,input_ids_ph,input_mask_ph,is_training_,is_training=True):
    feed_dict = {}
    input_ids, input_mask, segment_ids, label_ids = inputs[:]
    feed_dict[input_ids_ph] = input_ids
    feed_dict[input_mask_ph] = input_mask
    feed_dict[segment_ids_ph] = segment_ids
    # feed_dict[label_ph] = label_ids
    feed_dict[is_training_] = is_training
    return feed_dict



mode = 'predict'
data_ident = './checkpoint/20220420/sb-multilabel/'
# source_dir = '/disk1/sdsong/20220301/{}data/'.format(mode)
source_dir = './test_data/'
model_path = data_ident + 'frozen_model.onnx'
target_dir = './prediction/' + data_ident
vocab_path = data_ident + 'all_vocab_uniq.txt'
result_path = target_dir + 'prediction_'
max_seq_length = 200
batch_size = 800
no_label = (mode=='predict')
os.makedirs(target_dir, exist_ok=True)
max_type_length=6
custom_id = []
prediction_file_list = glob.glob(source_dir+'zaxd-multi-data*')

tokenizer = tokenization.FullTokenizer(
    vocab_file=vocab_path, do_lower_case=True)

print ('loading model:'+time.asctime( time.localtime(time.time()) ))
import onnxruntime as rt
sess = rt.InferenceSession(model_path,  providers=['CPUExecutionProvider'])
input_name = sess.get_inputs()[0].name
input_name2 = sess.get_inputs()[1].name
input_name3 = sess.get_inputs()[2].name
input_name4 = sess.get_inputs()[3].name
probability_name = sess.get_outputs()[0].name
print(probability_name)
probs = []
instance_count = 0
top_k_right_count = 0
label_list = ['0', '1']
file_id = 1
prediction_file_list = prediction_file_list[0:]
for pred_file in prediction_file_list:
    predict_label_ids_topk = []
    label_ids_test, label_ids_gold = [], []
    probability_list = []
    print('INFO: processing {}'.format(pred_file))
    file_name = os.path.basename(pred_file)
    print('loading files:'+time.asctime( time.localtime(time.time()) ))
    part_data_lines = dconstr.csv2line_data(pred_file, callback=data_processer)
    is_training=False
    part_data = []
    for i, line in enumerate(part_data_lines):
        guid = "%s-%s-%s" % ('prediction', file_name, i)
        example = lines2TransformerExample(line, guid, no_label=no_label)
        part_data.append(example)
    
    input_ids, input_mask, segment_ids, label_ids = \
    convert_examples_to_features(
    part_data, label_list, max_seq_length,
    tokenizer, no_label=no_label)
    # if no_label:
    #     custom_id.extend(label_ids) # for prediction mode
    data_iter_pred = dprovid.DataIter(
    (input_ids, input_mask, segment_ids, label_ids),
    batch_size=batch_size)
    batch_num = data_iter_pred._data_count
    print('batch number={}'.format(batch_num))
    probs = []
    print('iteration begins:'+time.asctime( time.localtime(time.time()) ))
    for i, inputs in enumerate(data_iter_pred):
        feed_dict = {
        input_name: inputs[0],
        input_name2: inputs[1],
        input_name3: [False], # False
        input_name4: inputs[2]
        }       
        # print('INFO: {}/{} batch'.format(i, batch_num))
        pred_onx = sess.run([probability_name], feed_dict)
        # print(pred_onx[0].shape)
        probability_list.append(pred_onx[0][:,-1])
        label_ids_gold.append(inputs[-1])
        print('batch:{}'.format(i)+time.asctime( time.localtime(time.time()) ))
    file_id = file_id + 1
    # probability
    if len(label_ids_gold)>=1:
        label_ids_gold = np.concatenate(label_ids_gold)
    if len(probability_list)>=1:
        probability_list = np.concatenate(probability_list, axis=0)
    path_test_result = result_path + file_name
    w_f = open(path_test_result,'w',encoding='utf-8')
    for id_cus,prob in zip(label_ids_gold,probability_list):
        w_f.write(id_cus + '\t' + str(prob) + '\n')
    w_f.close()
    print('result has wrote into: {0}'.format(path_test_result))
    # return label_ids_test, probability_list, predict_label_ids_topk
    print(time.asctime( time.localtime(time.time()) ))


# if not no_label
#     test_acc = sum((label_ids_gold == label_ids_test).astype(np.int32)) \
#                 / label_ids_gold.shape[0]
#     test_acc_topk = top_k_right_count / label_ids_gold.shape[0]
#     print('instance_count: {0}, acc: {1}, top-3 acc: {2}'.format(
#         instance_count, test_acc, test_acc_topk))
#     tf.logging.info('finished!')

