r_f = open('part-all-0009.txt','r',encoding='utf-8')
r_f_line = r_f.readlines()
w_f = open('part-all-0009-test.txt','w',encoding='utf-8')
count = 0
vocab_list = []
for line in r_f_line:
    #if count == 200:
    #    break
    count += 1
    lines = line.strip().split('\t')
    if lines[3] != 'null' or lines[4] != 'null':
        tmp = lines[1] + ','+lines[2] + ',' + lines[3] + ',' + lines[4].strip() + ',' +lines[5].strip()
        #if lines[0] == '1':
        #    label = 'pos'
        #else:
        #    label = 'neg'
        #vocab_list.extend(tmp.split(','))
        w_f.write(lines[0] + '\t' + tmp + '\n')
#w_f_vocab = open('vocab_list_test_v2.txt','w',encoding='utf-8')
#vocab_list = set(vocab_list)
#for vocab in vocab_list:
#    w_f_vocab.write(vocab + '\n')
#w_f_vocab.close()
r_f.close()
w_f.close()
