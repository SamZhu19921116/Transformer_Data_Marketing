#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

# save txt data into transformer needed: label \t string，

import os
import glob
import threading
import argparse as argp

MODE = 1

MODE_STR = {0:'all', 1:'no_both',2:'no_any'}

# multi-threads
class MultiThread():
    def __init__(self, func, args):
        self.args = args
        self.num = len(args)
        if not isinstance(func, list):
            func = [func]
        if len(func) == 1:
            self.func = func*self.num

    def run(self):
        thr = []
        for i in range(self.num):
            cur_func = self.func[i]
            cur_args = self.args[i]
            t = threading.Thread(target=cur_func, args=cur_args)
            thr.append(t)
        [t.start() for t in thr]
        [t.join() for t in thr]
        print('INFO:-------------processing finished -------------')
        return 0


def main_func(in_file, out_fp, vocabs, switch, filter, ban):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # here is the processing func
            result = data_processer(line, vocabs, MODE, switch, filter, ban)
            out_fp.write(result)


def data_processer(line, vocabs, mode, switch, filter, ban):
    '''
    give each data (line), save all the exist feature to the corresponding vocabs, 
    and use switch to control which features are useful 
    and use filter to denote which features are used to screen data
    '''
    # the order of features is label, id, type, area, applist, behavior, model, pack
    # line = line.replace('\tnull','').replace('null\t', '')
    items = line.strip().split('\t') 
    if items[0] == '0':
        label = 'neg'
    elif items[0] == '1':
        label = 'pos'
    feature_num = len(items)
    single_fea_indexes = [2, 3]
    list_fea_indexes = [4, 5]
    exist_ = list(filter)
    if feature_num>6:
        single_fea_indexes.append(6)
        list_fea_indexes.append(7)
    if feature_num<8:
        items.extend(['null']*(8-feature_num))
    for i in single_fea_indexes:
        if switch[i] == '0':
            continue
        if items[i] == 'null':
            exist_[i] = '0' # feature not exist
        vocabs[0].add(items[i])
        vocabs[i-1].add(items[i])

    for i in list_fea_indexes:
        if switch[i] == '0':
            continue
        if items[i] == 'null':
            exist_[i] = '0' # feature not exist
            elmts = ['null']
        else:
            elmts = items[i].split(',')
        vocabs[0].update(elmts)
        vocabs[i-1].update(elmts)
    
    exist_ = ''.join(exist_)
    any_null = not(exist_ == filter)
    both_null = '1' not in exist_
    if mode==2 and any_null:
        return '' # label + '\t' + '' + '\n'
    elif mode==1 and both_null:
        return '' # label + '\t' + '' + '\n'
    tmp = ''
    for i in range(2, feature_num):
        if switch[i] == '1':
            tmp = tmp + ',' + items[i] 
    tmp = tmp[1:].replace(',null','').replace('null,', '')
    for v in ban:
        tmp = tmp.replace(','+v,'').replace(v+',', '')
    result = label + '\t' + tmp + '\n'
    return result


def save_vacob(vocab, file_name):
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            fp.write(v+'\n')


def convert_data(data_dir, target_dir, mode, switch, filter, ban, save_vocab=True):
    '''
    convert data for transformer
    '''
    if (mode=='train') or (mode=='both'):
        # training dataset
        train_dir = os.path.join(data_dir, 'traindata/')
        train_file_list = glob.glob(train_dir+'*.txt')
        os.makedirs(target_dir, exist_ok=True)
        target_train_data = os.path.join(target_dir,'train_data')
        fp_tmp = open(target_train_data, "w", encoding='utf-8')
        fp_tmp.close()
        out_fp = open(target_train_data, 'a', encoding='utf-8')
        args = []
        vocabs = [set(), set(), set(), set(), set(), set(), set()]
        for i in train_file_list:
            args.append((i, out_fp, vocabs, switch, filter, ban))
        mthread = MultiThread(main_func, args)
        mthread.run()
        out_fp.close()
        if save_vocab:
            for i, v in enumerate(vocabs):
                v = list(v)
                vocabs[i] = v
                v.sort()
            vocabs[0].insert(0, '[MASK]')
            vocabs[0].insert(0, '[SEP]')
            vocabs[0].insert(0, '[CLS]')
            vocabs[0].insert(0, '[UNK]')
            vocabs[0].insert(0, '[PAD]')

            # save vocab
            vocab_names = ['all_vocab.txt', 'train_dvc.txt', 'train_area.txt', 'train_app.txt','train_behavior.txt','train_model.txt','train_pack.txt']
            for i in range(len(vocab_names)):
                vocab_path = os.path.join(target_dir, vocab_names[i])
                save_vacob(vocabs[i], vocab_path)

    if (mode=='test') or (mode=='both'):
        # test dataset
        test_dir = os.path.join(data_dir, 'testdata/')
        test_file_list = glob.glob(test_dir+'*.txt')
        os.makedirs(target_dir, exist_ok=True)
        target_test_data = os.path.join(target_dir,'test_data')
        fp_tmp = open(target_test_data, "w", encoding='utf-8')
        fp_tmp.close()
        out_fp = open(target_test_data, 'a', encoding='utf-8')
        args = []
        vocabs = [set(), set(), set(), set(), set(), set(), set()]
        for i in test_file_list:
            args.append((i, out_fp, vocabs, switch, filter, ban))
        mthread = MultiThread(main_func, args)
        mthread.run()
        out_fp.close()




if __name__ == '__main__':

    parse = argp.ArgumentParser(prog='data4transformer', usage='python data4transformer.py -d data_dir -t target_dir -m both -s 1111111111 -f 0000110000', description='convert data for transformer. data in line looks like: pos x1,x2,x3,', add_help=True)
    parse.add_argument('-d', '--data_dir', required=True, type=str, help='The dir contains "traindata" and "testdata" folders.')
    parse.add_argument('-t', '--target_dir', required=True, type=str, help='Where to save the converted (into files named as train_data and test_data).')
    parse.add_argument('-m', '--mode', type=str, default='both', help='valid values: test, train, both. Indicating to convert training data, test data or both.')
    parse.add_argument('-s', '--switch', type=str, default='1111111111', help='A string contains only 1 and 0 to indicate use the feature or not (including label and id if exist).')
    parse.add_argument('-f', '--filter', type=str, default='0000110000', help='A string contains only 1 and 0 to filt data that contains no specified feature.')
    parse.add_argument('-b', '--ban', type=str, default='', help='A list contains some forbidden feature values.')
    args = parse.parse_args()
    data_dir, target_dir, mode, switch, filter = args.data_dir, args.target_dir, args.mode, args.switch, args.filter
    ban = args.ban.split(',')
    # data_dir = './data/yqg-intent-addpack-posandneg2random/'
    # target_dir = './data/20220329/'
    # mode = 'both'
    # switch = '1111010100'
    # filter = '0000010100'
    # ban = ['com.lingyue.zebraloan']
    convert_data(data_dir, target_dir, mode, switch, filter, ban)

