# coding: utf-8
# __author__ = "xiaowang11"

# coding=utf-8

import logging
import sys
import numpy as np
from collections import defaultdict
import re

import collections
import unicodedata
import six
import tensorflow as tf

# define a logger
logging.basicConfig(format="%(message)s", level=logging.INFO)


# generate one line from file once
def file_generator(file_path, coding="utf-8"):
    compiler_version = sys.version[0]
    file_oper = get_file_obj(file_path)

    with open(file_path, "r+"):
        line = file_oper.readline()

        while line:
            # Python2中普通字符串实际上就是已经编码(非Unicode)的字节字符串'utf-8'。
            # 在Python3中，不必加入这个前缀字符，否则是语法错误，这是因为所有的字符串默认已经是Unicode编码了
            line = line.strip().decode(coding) if compiler_version == "2" else line.strip()

            yield line
            line = file_oper.readline()


# return a file obj ignore python version
def get_file_obj(file_path, mode="r+", coding="utf-8"):
    compiler_version = sys.version[0]

    return open(file_path, mode) if compiler_version == "2" else open(file_path, mode, encoding=coding)


def chunks(l, n):
    for i in range(0, len(l), n):

        yield l[i:i+n]


# save test sent info according to origin sort
def get_test_info(data_path, word2idx, unroll_steps=60, mode="char"):
    test_list = []
    idx = 0

    for line in file_generator(data_path):
        idx += 1
        if idx == 1 or len(line.strip()) < 2:
            continue
        infos = line.split("\t")
        test_sent = skip_spe_char(infos[0])

        test_list.append([test_sent, sent_to_idx(test_sent, word2idx, unroll_steps, mode=mode)[0], infos[2]])

    return test_list


def get_recall_info(data_path, word2idx, test_list, unroll_steps=60, mode="char"):
    idx = 0
    real_test_sent = None
    recall_info = []

    for line in file_generator(data_path):
        if len(line.strip()) < 2:
            recall_info.append([])
            real_test_sent = None
            continue

        infos = line.strip().split("\t")
        test_sent = skip_spe_char(infos[0])

        if not real_test_sent:
            real_test_sent = test_sent
            while skip_spe_char(test_list[idx][0]) != real_test_sent:
                idx += 1
            if test_list[idx][0] == real_test_sent:
                recall_info[-1].append([real_test_sent, test_list[idx][1], test_list[idx][2]])

        recall_info[-1].append([skip_spe_char(infos[2]), sent_to_idx(skip_spe_char(infos[2]), word2idx, unroll_steps, mode=mode)[0], infos[3]])

    return recall_info


def sent_to_idx(sent, word2idx, sequence_len=30, mode="word"):

    sent2idx = []
    parts = sent.strip("_").split("_") if mode == "word" \
        else list(sent.replace("_", "").replace("<a>", ""))

    parts = ['[CLS]'] + parts

    if len(parts) < sequence_len:
        for k in range(len(parts), sequence_len):
            parts.append('[PAD]')
    idx = 0

    for i in range(sequence_len):
        word = parts[i]
        if word in word2idx:
            sent2idx.append(word2idx[word])
            if word != '[PAD]':
                idx += 1
        else:
            sent2idx.append(word2idx['[UNK]'])

    return sent2idx, idx


def skip_spe_char(ori_str):
    re_str = re.sub(r"[@ %#_,，()（）？。]", "", ori_str)

    return re_str


# Add load train data in char
def load_train_data(filename, word2idx, sequence_len, num=10, mode="char", train_data_path="random_epoch_data"):
    w_f = get_file_obj(train_data_path, 'w+')
    qq_list = []
    knowledge_q_dic = {}  # store knowledge and its questions {knowledge:[q1,q2...]}

    for line in file_generator(filename):
        if "insert" not in line:
            continue
        line = line.encode("utf-8") if sys.version[0] == '2' else line
        infos = str.lower(line).split('\t')
        if infos[6] not in knowledge_q_dic:
            knowledge_q_dic[infos[6]] = []
        knowledge_q_dic[infos[6]].append(skip_spe_char(infos[2]))

    for key, value in knowledge_q_dic.items():  # generate positive items
        for v in value:
            temp_list = []
            for vv in value:
                temp_list.append(vv)
            write_line = '1 qid:0 ' + v.strip()

            while v in temp_list:
                temp_list.remove(v)

            positive = temp_list if len(temp_list) < num else np.random.choice(temp_list, size=[10])

            if v in positive:
                print(False)
            if len(positive) == 0:
                positive.append(v)

            for p in positive:
                temp_line = write_line + ' ' + p + ' ' + key
                w_f.write(temp_line + "\n")
                temp_line = temp_line.decode("utf-8") if sys.version[0] == '2' else temp_line
                qq_list.append(temp_line)
    w_f.close()
    ori_quests, cand_quests, zsd_quests = [], [], []

    for line in qq_list:
        arr = line.strip().split(" ")
        ori_quest, _ = sent_to_idx(arr[2], word2idx, sequence_len, mode=mode)
        cand_quest, _ = sent_to_idx(arr[3], word2idx, sequence_len, mode=mode)
        zsd_quest = arr[4]
        ori_quests.append(ori_quest)
        cand_quests.append(cand_quest)
        zsd_quests.append(zsd_quest)
    logging.info("load train data finish!")

    return ori_quests, cand_quests, zsd_quests


def batch_iter(ori_quests, cand_quests, zsd_quests, batch_size, is_valid=False):
    """
    iterate the data
    """
    data_len = len(ori_quests)
    batch_num = int((data_len-1)/batch_size) + 1
    ori_quests = np.array(ori_quests)
    cand_quests = np.array(cand_quests)
    zsd_quests = np.array(zsd_quests)

    if is_valid is not True:
        shuffle_idx = np.random.permutation(np.arange(data_len))
        ori_quests = ori_quests[shuffle_idx]
        cand_quests = cand_quests[shuffle_idx]
        zsd_quests = zsd_quests[shuffle_idx]
    for batch in range(batch_num):
        start_idx = batch * batch_size
        start_idx_count = batch * batch_size
        end_idx = min((batch + 1) * batch_size, data_len)
        act_batch_size = end_idx - start_idx

        # get negative questions
        if is_valid:
            neg_quests = cand_quests[start_idx: end_idx]
        else:
            randi_list = []

            while len(randi_list) != act_batch_size:
                for idx in np.random.randint(0, int(data_len), 5 * act_batch_size):

                    if len(randi_list) < act_batch_size and idx < int(data_len) \
                            and zsd_quests[idx] != zsd_quests[start_idx_count]:
                       start_idx_count = start_idx_count + 1
                       randi_list.append(idx)
            neg_quests = [cand_quests[idx] for idx in randi_list]

        yield (ori_quests[start_idx: end_idx], cand_quests[start_idx: end_idx], np.array(neg_quests))


def convert_to_unicode(text):
  """Converts `text` to Unicode (if it's not already), assuming utf-8 input."""
  if six.PY3:
    if isinstance(text, str):
      return text
    elif isinstance(text, bytes):
      return text.decode("utf-8", "ignore")
    else:
      raise ValueError("Unsupported string type: %s" % (type(text)))
  elif six.PY2:
    if isinstance(text, str):
      return text.decode("utf-8", "ignore")
    elif isinstance(text, unicode):
      return text
    else:
      raise ValueError("Unsupported string type: %s" % (type(text)))
  else:
    raise ValueError("Not running on Python2 or Python 3?")


def load_vocab(vocab_file):
    """Loads a vocabulary file into a dictionary."""
    vocab = collections.OrderedDict()
    index = 0
    with tf.gfile.GFile(vocab_file, "r") as reader:
        while True:
            token = convert_to_unicode(reader.readline())
            if not token:
                break
            token = token.strip()
            vocab[token] = index
            index += 1
    return vocab
