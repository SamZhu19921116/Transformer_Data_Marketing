#!/use/bin/env/ python3
# -*- coding: UTF-8 -*-

# 根据 app 名称 生成 dict : 'app name': [一级标签，[二级标签]]

# import csv
import codecs
import argparse as argp


def load_cate_table(cate_path):
    '''
    load 标签
    '''
    pack_dict = dict()
    fp = codecs.open(cate_path, mode='r', encoding='utf-8')
    lines = fp.readlines()
    fp.close()
    for i, line in enumerate(lines):
        if i==0:
            continue
        app_name, pack_name, primary_label = line.strip().split('\t')
        if pack_name in pack_dict:
            print('warning: repeated pack name: {} !'.format(pack_name))
        else:
            pack_dict[pack_name] = eval(primary_label)
    return pack_dict


def cate_id2simple_id(pack_dict):
    simple_id = set()
    for app in pack_dict:
        simple_id.update(pack_dict[app])
    simple_id = list(simple_id)
    simple_id.sort()
    simple_id_dict = dict(zip(simple_id, range(len(simple_id))))
    return simple_id_dict


def get_simple_idx(pack_dict, simple_id_dict):
    for app in pack_dict:
        ids = []
        for cate in pack_dict[app]:
            ids.append(simple_id_dict[cate])
        pack_dict[app] = ids
    return pack_dict


def load_simple_cate_table(cate_path):
    '''
    load 标签
    '''
    pack_dict = dict()
    fp = codecs.open(cate_path, mode='r', encoding='utf-8')
    lines = fp.readlines()
    fp.close()
    for i, line in enumerate(lines):
        if i==0:
            continue
        pack_name, primary_label = line.strip().split('\t')
        if pack_name in pack_dict:
            print('warning: repeated pack name: {} !'.format(pack_name))
        else:
            pack_dict[pack_name] = eval(primary_label)
    return pack_dict


if __name__ == '__main__':
    # cate_path = './data_analysis/package_cate_ids.txt'
    cate_path = './data_analysis/gtlabel.txt'
    # parse = argp.ArgumentParser(prog='pack2gtcate', usage='python pack2gtcate.py -p cate_path', description='map category of pack into ids according to the getui category table.', add_help=True)
    # parse.add_argument('-p', '--cate_path', required=True, type=str, help='The file, which contains pack and category mpacking.')
    # args = parse.parse_args()
    # cate_path = args.cate_path
    app_dict = load_cate_table(cate_path)
    simple_id_dict = cate_id2simple_id(app_dict)
    print('INFO: There are {} category in total.'.format(len(simple_id_dict)))
    app_dict = get_simple_idx(app_dict, simple_id_dict)