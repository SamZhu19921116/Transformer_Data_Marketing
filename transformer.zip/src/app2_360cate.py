#!/use/bin/env/ python3
# -*- coding: UTF-8 -*-

# 根据 app 名称 生成 dict : 'app name': [一级标签，[二级标签]]

# import csv
import codecs
import argparse as argp


def load_cate_table(cate_path):
    '''
    load 标签
    '''
    app_dict = dict()
    fp = codecs.open(cate_path, mode='r', encoding='utf-8')
    lines = fp.readlines()
    fp.close()
    for i, line in enumerate(lines):
        if i==0:
            continue
        app_name, pack_name, primary_label = line.strip().split('\t')
        if app_name in app_dict:
            print('warning: repeated app name: {} !'.format(app_name))
        else:
            app_dict[app_name] = eval(primary_label)
    return app_dict


def cate_id2simple_id(app_dict):
    simple_id = set()
    for app in app_dict:
        simple_id.update(app_dict[app])
    simple_id = list(simple_id)
    simple_id.sort()
    simple_id_dict = dict(zip(simple_id, range(len(simple_id))))
    return simple_id_dict


def get_simple_idx(app_dict, simple_id_dict):
    for app in app_dict:
        ids = []
        for cate in app_dict[app]:
            ids.append(simple_id_dict[cate])
        app_dict[app] = ids
    return app_dict


def load_simple_cate_table(cate_path):
    '''
    load 标签
    '''
    app_dict = dict()
    fp = codecs.open(cate_path, mode='r', encoding='utf-8')
    lines = fp.readlines()
    fp.close()
    for i, line in enumerate(lines):
        if i==0:
            continue
        app_name, primary_label = line.strip().split('\t')
        if app_name in app_dict:
            print('warning: repeated app name: {} !'.format(app_name))
        else:
            app_dict[app_name] = eval(primary_label)
    return app_dict


if __name__ == '__main__':
    # cate_path = './data_analysis/package_cate_ids.txt'
    cate_path = './data_analysis/360spiderlabel.txt'
    # parse = argp.ArgumentParser(prog='app2_360cate', usage='python app2_360cate.py -p cate_path -p2 pri2sec_mapping_path', description='map category of app into ids according to the 360 category table.', add_help=True)
    # parse.add_argument('-p', '--cate_path', required=True, type=str, help='The file, which contains app and category mapping.')
    # args = parse.parse_args()
    # cate_path = args.cate_path
    app_dict = load_cate_table(cate_path)
    simple_id_dict = cate_id2simple_id(app_dict)
    print('INFO: There are {} category in total.'.format(len(simple_id_dict)))
    app_dict = get_simple_idx(app_dict, simple_id_dict)
    print(app_dict['微信'])
    print(app_dict['六艺'])
