#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

# save txt data into transformer needed: label \t string，

import os
import glob
import threading
import argparse as argp
import random
import json
import copy

MODE = 1

VALID_FILTER_MODE = {'and', 'or'}

# VALID_LABELS = ["neg", "Dintent", "reach", "click", "signup", "nonauth", "auth"]
VALID_LABELS = [str(i) for i in range(10)]


# multi-threads
class MultiThread():
    def __init__(self, func, args):
        self.args = args
        self.num = len(args)
        if not isinstance(func, list):
            func = [func]
        if len(func) == 1:
            self.func = func*self.num

    def run(self):
        thr = []
        for i in range(self.num):
            cur_func = self.func[i]
            cur_args = self.args[i]
            t = threading.Thread(target=cur_func, args=cur_args)
            thr.append(t)
        [t.start() for t in thr]
        [t.join() for t in thr]
        print('INFO:-------------processing finished -------------')
        return 0


def main_func(in_file, out_fp, config):
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # here is the processing func
            result = data_processer(line, config)
            out_fp.write(result)


def data_processer(line, config):
    '''
    give each data (line), save all the exist feature to the corresponding vocabs, 
    :config: the needed parameters for convert each line 
        switch: to control which features are useful 
        filter: to denote which features are used to screen data
        ban: to spicify the feature value need to be delete
        ratios: to control sample numbers of each class 
    '''
    # the order of features is label, id, type, area, applist, behavior, model, pack
    # line = line.replace('\tnull','').replace('null\t', '')
    items = line.strip().split('\t') 
    label = VALID_LABELS[int(items[0])]
    fea_len = len(items)
    exist_ = list(config['filter'])
    if len(items)<config['feature_num']:
        items.extend(['null']*(config['feature_num']-fea_len))
    for i in range(config['feature_num']):
        if config['switch'][i] == '0': # no need for this feature
            continue
        if items[i] == 'null':
            exist_[i] = '0' # needed feature not exist
        if config['type'][i] == '0': # single value type
            config['vocabs'][0].add(items[i])
            config['vocabs'][i+1].add(items[i])
        elif config['type'][i] == '1': # list type:
            elmts = items[i].split(',')
            config['vocabs'][0].update(elmts)
            config['vocabs'][i+1].update(elmts)
    exist_ = ''.join(exist_)
    has_null = not(exist_ == config['filter']) # has null value in filtering features
    all_null = '1' not in exist_              # filtering features are all null values
    if config['filter_mode']=='or' and has_null:
        return '' # label + '\t' + '' + '\n'
    elif config['filter_mode']=='and' and all_null:
        return '' # label + '\t' + '' + '\n'
    rand = random.random()
    # randomly filter to control sample number
    if rand > config['ratio'][int(items[0])]:
        return ''
    tmp = ''
    for i in range(2, config['feature_num']):
        if config['switch'][i] == '1':
            tmp = tmp + ',' + items[i] 
    tmp = tmp[1:].replace(',null','').replace('null,', '')
    for v in config['ban']:
        tmp = tmp.replace(','+v,'').replace(v+',', '')
    result = label + '\t' + tmp + '\n'
    return result


def save_vacob(vocab, file_name):
    with open(file_name, 'w', encoding='utf-8') as fp:
        for v in vocab:
            fp.write(v+'\n')


def convert_data(config):
    '''
    convert data for transformer
    '''
    data_dir = config.pop('data_dir')
    target_dir = config.pop('target_dir')
    mode = config.pop('mode')
    if (mode=='train') or (mode=='both'):
        # training dataset
        train_dir = os.path.join(data_dir, 'traindata/')
        train_file_list = glob.glob(train_dir+'*.txt')
        os.makedirs(target_dir, exist_ok=True)
        target_train_data = os.path.join(target_dir,'train_data')
        fp_tmp = open(target_train_data, "w", encoding='utf-8')
        fp_tmp.close()
        out_fp = open(target_train_data, 'a', encoding='utf-8')
        args = []
        for i in train_file_list:
            args.append((i, out_fp, config))
        mthread = MultiThread(main_func, args)
        mthread.run()
        out_fp.close()
        vocabs = [0] * len(config['vocabs'])
        for i, v in enumerate(config['vocabs']):
            v = list(v)
            vocabs[i] = v
            v.sort()
        vocabs[0].insert(0, '[MASK]')
        vocabs[0].insert(0, '[SEP]')
        vocabs[0].insert(0, '[CLS]')
        vocabs[0].insert(0, '[UNK]')
        vocabs[0].insert(0, '[PAD]')

        # save vocab
        vocab_names = config['vocab_names']
        for i in range(len(vocab_names)):
            vocab_path = os.path.join(target_dir, vocab_names[i])
            save_vacob(vocabs[i], vocab_path)

    if (mode=='test') or (mode=='both'):
        # test dataset
        test_dir = os.path.join(data_dir, 'testdata/')
        test_file_list = glob.glob(test_dir+'*.txt')
        os.makedirs(target_dir, exist_ok=True)
        target_test_data = os.path.join(target_dir,'test_data')
        fp_tmp = open(target_test_data, "w", encoding='utf-8')
        fp_tmp.close()
        out_fp = open(target_test_data, 'a', encoding='utf-8')
        args = []
        for i in test_file_list:
            args.append((i, out_fp, config))
        mthread = MultiThread(main_func, args)
        mthread.run()
        out_fp.close()


def analysis_example(data_path):
    '''
    By reading a data file in given folder and analyzing one example, the feature number can be obtained, 
    
    :data_path: the folder contains the training and test data files
    '''
    train_dir = os.path.join(data_path, 'traindata/')
    train_file_list = glob.glob(train_dir+'*.txt')
    print(train_dir)
    example_file = train_file_list[0]
    with open(example_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        example_line = lines[0]
    items = example_line.split('\t')
    feature_num = len(items) # the 1st is label, the 2nd is user_id, the rest is real features
    return feature_num


def auto_sample_ratio(config):
    '''
    auto calculate ratio for each kinds of data according to the following rules:
      1. keep all the data whose label surpasses 3 (noto included)
      2. the number of data labeled as 1, 2, 3 equals to label 4
      3. the number of data labeled as 0 equals to the rest kinds
    '''
    cntinfo_dir = os.path.join(config['data_dir'], 'cntinfo')
    cntinfo_file = glob.glob(os.path.join(cntinfo_dir, '*.txt'))
    cntinfo_file = cntinfo_file[0]
    numbers = []
    with open(cntinfo_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for i, line in enumerate(lines):
            level, num = line.strip().split('\t')
            numbers.append(int(num))
    numbers.reverse() # change the order to be 0 to the last 
    ratio = [1] * len(numbers)
    for i in range(1, 4):
        ratio[i] = min(numbers[4]/(numbers[i]+10e-8), 1.0)
    pos_num = 0
    for i in range(1, len(numbers)):
        pos_num = pos_num + numbers[i]
    ratio[0] = min(pos_num/numbers[0], 1.0)
    return ratio


def initial_config(args, config_file='./configs/data4transformer.json'):
    '''
    initialize necessary variables by combining input arguements and config file.
    :feature_num: the number of feature 
    '''
    fp = open(config_file)
    rough_config = json.load(fp)
    config = copy.copy(rough_config)
    for key in rough_config:
        arg_value = getattr(args, key, None)
        if arg_value:
            config[key] = arg_value
        if key.startswith('_comment'):
            config.pop(key)
    feature_num = analysis_example(config['data_dir'])
    vocabs = [set()]
    vocab_names = ['all_vocab_uniq.txt']
    for i in range(feature_num):
        vocabs.append(set())
        vocab_names.append('fea{}_vocab.txt'.format(i))
    config['vocabs'] = vocabs
    config['vocab_names'] = vocab_names
    config['feature_num'] = feature_num

    # explain the ratio for each kinds of data
    if config['ratio']=='None' or config['ratio'] is None:
        config['ratio'] = auto_sample_ratio(config)
    elif isinstance(config['ratio'], str):
        items = config['ratio'].split(',')
        for i in range(len(items)):
            items[i] = float(items[i])
        config['ratio'] = items
    return config



if __name__ == '__main__':

    # os.chdir('./multiloss_transformer')
    parse = argp.ArgumentParser(prog='data4transformer_multiloss', usage='python data4transformer_multiloss.py -d data_dir -t target_dir -m both -s 1111111111 -f 0000110000', description='convert data for transformer. data in line looks like: pos x1,x2,x3,', add_help=True)
    parse.add_argument('-d', '--data_dir', default=None, type=str, help='The dir contains "traindata" and "testdata" folders.')
    parse.add_argument('-t', '--target_dir', default=None, type=str, help='Where to save the converted files (named as train_data and test_data).')
    parse.add_argument('-m', '--mode', type=str, default=None, help='Valid values: test, train, both. Indicating to convert training data, test data or both.')
    parse.add_argument('-s', '--switch', type=str, default=None, help='A string contains only 1 and 0 to indicate use the feature or not (including label and id if exist).')
    parse.add_argument('-p', '--type', type=str, default=None, help='A string contains only 1 and 0 to indicate the type of the feature is a single value or a list.')
    parse.add_argument('-f', '--filter', type=str, default=None, help='A string contains only 1 and 0 to filter out data that contains no specified feature.')
    parse.add_argument('-a', '--filter_mode', type=str, default=None, help='A string "and"/"or" to indicate use the above filter features .')
    parse.add_argument('-b', '--ban', type=list, default=None, help='A list contains some forbidden feature values.')
    parse.add_argument('-r', '--ratio', type=list, default=None, help='Give ratio to control samples for each class.')
    args = parse.parse_args()

    # args.data_dir = './data_zaxd/20220414/'
    # args.target_dir = './data_zaxd/20220414/'
    # args.mode = 'train'
    # args.switch = '1111111000'
    # args.filter = '0000110000'
    # args.ban = ['众安小贷','众安贷']
    # args.ratios = [0.4, 0.10, 1.0, 1, 1, 1, 1]

    config = initial_config(args, config_file='./configs/data4transformer.json')
    convert_data(config)


