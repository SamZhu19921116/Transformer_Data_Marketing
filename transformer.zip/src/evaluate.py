#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import numpy as np
# import pandas as pd
import matplotlib.pyplot as plt
import sklearn.metrics as sm
from sklearn.metrics import accuracy_score, f1_score, auc, roc_curve, roc_auc_score
import os

THRESHOLD = 0.5
MODEL_NAME = ''

def get_loss_fig(train_loss, test_loss, cols=['final_loss'], title='loss', file_name='loss.png', is_show=True):
    loss_list = cols
    color_list = ["r", "b"]
    plt.figure()
    cnt = 0
    for k in loss_list:
        loss = train_loss[k]
        step = list(np.arange(len(loss)))
        plt.plot(step,loss,color_list[cnt]+"-",label="train_" + k, linestyle="--")
        cnt += 1
    cnt = 0
    for k in loss_list:
        loss = test_loss[k]
        step = list(np.arange(len(loss)))
        plt.plot(step,loss,color_list[cnt],label="test_" + k)
        cnt += 1
    plt.title(title)
    plt.xlabel('iteration')
    plt.ylabel(title)
    plt.legend()
    # clear_output()
    os.makedirs("./loss/" + MODEL_NAME, exist_ok=True)
    plt.savefig("./loss/" + MODEL_NAME + "/{}".format(file_name))
    # clear_output()
    if is_show:
        plt.show()


def plot_roc(labels, predict_prob, file_name='roc.png', is_show=False):
    false_positive_rate,true_positive_rate,thresholds=roc_curve(labels, predict_prob)
    roc_auc=auc(false_positive_rate, true_positive_rate)
    plt.title('ROC')
    plt.plot(false_positive_rate, true_positive_rate,'b',label='AUC = %0.4f'% roc_auc)
    plt.legend(loc='lower right')
    plt.plot([0,1],[0,1],'r--')
    plt.ylabel('TPR')
    plt.xlabel('FPR')
    plt.show()
    if is_show:
        plt.show()


def get_loss_fig_aux(train_loss_data, test_loss_data):
    train_loss = {
        "final_loss":list(train_loss_data["train_" + "final_loss"].values)
    }
    test_loss = {
        "final_loss":list(test_loss_data["test_" + "final_loss"].values)
    }
    get_loss_fig(train_loss, test_loss)



def run_evaluate(prediction_file=None, loss_file_name=None, test_label=None, result_file=None):

    if result_file:
        fp = open(result_file, 'w+', encoding='utf-8')
    else:
        fp = None
    test_label = np.array(test_label)
    positive_num = len(test_label[test_label == 1])
    negative_num = len(test_label[test_label == 0])
    print("[test dataset]pos:neg=%d : %d" % (positive_num, negative_num), file=fp)

    y_true= test_label
    y_score = np.loadtxt(prediction_file)[:,-1]
    auc_score = roc_auc_score(y_true,y_score)
    print('auc_score: {}'.format(auc_score), file=fp)

    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    print('ks: {}'.format(max(tpr-fpr)), file=fp)
    ks_thres = thresholds[np.argmax(tpr-fpr)]
    print('ks_thres: {}'.format(ks_thres), file=fp)

    acc, m, r, f1 = try_threshold(THRESHOLD, y_true, y_score, fp=fp)
    plot_roc(y_true, y_score)
    # if loss_file_name:
    #     train_loss_data = pd.read_csv ("/loss/"+ MODEL_NAME +"/train_" + loss_file_name)
    #     test_loss_data = pd.read_csv("/loss/"+ MODEL_NAME +"/test_" + loss_file_name)
    #     get_loss_fig_aux(train_loss_data, test_loss_data)
    
    if result_file:
        print(fp.readlines())
        fp.close()


def try_threshold(threshold, y_true, y_score, fp=None):
    y_pre = y_score.copy()
    y_pre[y_score >threshold] = 1
    y_pre[y_score < threshold] = 0
    # y_pre = np.argmax(y_score)
    print('==========================================================================', file=fp)
    print('given threshold:{}, acc: {}'. format(threshold, accuracy_score(y_true, y_pre)), file=fp)

    acc = accuracy_score(y_true, y_pre)
    print('acc :', acc, file=fp)

    m = sm.confusion_matrix(y_true, y_pre)
    print('confusion matrix :', m, sep='\n', file=fp)
    
    r= sm.classification_report(y_true, y_pre, digits=4)
    print('classification report :', r, sep='\n', file=fp)
    f1 = f1_score(y_true, y_pre)
    print('f1_score : {}'.format(f1), file=fp)
    print('==========================================================================', file=fp)
    return acc, m, r, f1
    
    
