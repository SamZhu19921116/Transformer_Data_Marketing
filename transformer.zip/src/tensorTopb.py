import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import warnings
warnings.filterwarnings("ignore")
import tensorflow as tf
from tensorflow.python.framework import graph_util
import argparse as argp

def freeze_graph(input_checkpoint, output_graph, log_path):
    '''
    :param input_checkpoint:
    :param output_graph: PB模型保存路径
    :return:
    '''
    # checkpoint = tf.train.get_checkpoint_state(model_folder) #检查目录下ckpt文件状态是否可用
    # input_checkpoint = checkpoint.model_checkpoint_path #得ckpt文件路径
 
    # 指定输出的节点名称,该节点名称必须是原模型中存在的节点
    output_node_names = "loss/Softmax"
    saver = tf.train.import_meta_graph(input_checkpoint + '.meta', clear_devices=True)
 
    with tf.Session() as sess:
        saver.restore(sess, input_checkpoint) #恢复图并得到数据
        # tensor_name_list = [tensor.name for tensor in sess.graph_def.node]
        # for node in tensor_name_list:
        #     print(node)
        # exit()
        # print(sess.graph_def)
        # sess.graph_def.node[-20].name='loss/Sofxmax'
        # tf.identity(tf.get_default_graph().get_tensor_by_name("Sofxmax_4"), name="loss/Sofxmax")
        output_graph_def = graph_util.convert_variables_to_constants(  # 模型持久化，将变量值固定
            sess=sess,
            input_graph_def=sess.graph_def,# 等于:sess.graph_def
            output_node_names=output_node_names.split(","))# 如果有多个输出节点，以逗号隔开
 
        with tf.gfile.GFile(output_graph, "wb") as f: #保存模型
            f.write(output_graph_def.SerializeToString()) #序列化输出
        fp = open(log_path, mode='w')
        for node in output_graph_def.node:
            print(node.name, file=fp)
        print("%d ops in the final graph." % len(output_graph_def.node), file=fp) #得到当前图有几个操作节点
        
if __name__ == "__main__":

    # base_path = './checkpoint/20220414/sb-multilabel_nomodel' # '20220329/yqg-intent-addpack-posandneg2random/no_both_new2'
    # # 输入ckpt模型路径
    # model_path = base_path+'/best_model18' # 'model/model/best_model'
    # # 输出pb模型的路径
    # target_path = base_path+"/frozen_model.18.pb"
    parse = argp.ArgumentParser(prog='tensorTopb', usage='python tensorTopb.py -p model_path -t target_path', description='convert checkpoint into pb model.', add_help=True)
    parse.add_argument('-p', '--model_path', default=None, type=str, help='The model path.')
    parse.add_argument('-t', '--target_path', default=None, type=str, help='The target pb model path.')
    parse.add_argument('-l', '--log_path', default='log/pb_log', type=str, help='The log path.')
    args = parse.parse_args()
    model_path = args.model_path
    if not args.target_path:
        target_path = os.path.join(os.path.dirname(args.model_path),'frozen_model.pb')
    # 调用freeze_graph将ckpt转为pb
    freeze_graph(model_path, target_path, args.log_path)
    print(target_path)
