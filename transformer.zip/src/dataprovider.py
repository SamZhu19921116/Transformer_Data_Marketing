#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import math
import random 
import numpy as np


class DataIter(object):

  def __init__(self, data, batch_size, seed=1337):
    """加载分类数据
    Args:
      data: tuple or list 
      batch_size: int, batch size
      seed: int or None, if int, used for shuffle data
    """
    # self.input_ids, self.input_mask, self.segment_ids, self.label_ids = data[:]
    self.input_data = []
    for elem in data:
        self.input_data.append(elem)
    self._batch_size = batch_size
    self._seed = seed

    self._data_count = len(elem) # self.input_ids.shape[0]
    self._iter_variable = 0
    self._data_ids = np.array(range(self._data_count))

    # batch count
    self._batch_count = int(math.ceil(self._data_count/self._batch_size))

  def shuffle(self):
    """shuffle data"""
    if isinstance(self._seed, int):
      random.seed(self._seed)
    random.shuffle(self._data_ids)

  def _generate_batch(self, start, end):
    """generate batch
    Args:
      start: int, start data id
      end: int, end data id

    Returns:
      data_dict: dict({'source': np.array, 'target': np.array})

    labels:
    """
    batch_indices = []
    for idx in range(start, end, 1):
      data_id = self._data_ids[idx]
      batch_indices.append(data_id)
    batch_indices = np.array(batch_indices)
    out_batch = []
    for elem in self.input_data:
        out_batch.append(elem[batch_indices])
    return out_batch

  def __len__(self):
    raise self._data_count

  def __iter__(self):
    self._iter_variable = 0
    return self

  def __next__(self):
    start = self._iter_variable
    end = self._iter_variable + self._batch_size
    if end > self._data_count:
      end = self._data_count
    if self._iter_variable > self._data_count or start >= end:
      self.shuffle()
      raise StopIteration()
    self._iter_variable = end
    return self._generate_batch(start, end)

  next = __next__  # Python 2

  @property
  def batch_count(self):
    return self._batch_count

  @property
  def batch_size(self):
    return self._batch_size

  @property
  def data_count(self):
    return self._data_count

