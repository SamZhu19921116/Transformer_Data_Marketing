#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import re
import os
import glob
import argparse as argp
import json


def update_params(args, train_cfg_file='./configs/train_transformer.json'):
    '''
    load training config file and inference
    '''
    cfg_fp = open(train_cfg_file)
    train_config = json.load(cfg_fp)
    cfg_fp.close()
    log_file = args.log_file or train_config['log_file']
    chkpt_dir = args.chkpt_dir or train_config['output_dir']
    std_out_idx = args.std_out_idx or train_config['std_out_idx']
    met_weights = args.met_weights
    return log_file, chkpt_dir, std_out_idx, met_weights


def choose_chkpt(log_file='./log/train_log', chkpt_dir='./checkpoint/', std_out_idx=4, met_weights=None):
    '''
    choose one valid checkpoint according to the metrics in the log.
    the 'std_out_idx' indicates the observed metric and 'met_weights' 
    means the valid loss, acc, auc, precis, 
    '''
    fp = open(log_file)
    lines = fp.readlines()
    pat_net_name = '(best_model.*)!'
    pat_valid_loss = 'valid loss:\s?([\.\d]+)'
    pat_valid_acc = 'valid acc:\s?(\[[,\s\.\d]+\])'
    pat_valid_auc = 'valid auc:\s?(\[[,\s\.\d]+\])'
    pat_valid_precis = 'valid precis:\s?(\[[,\s\.\d]+\])'
    pat_valid_recall = 'valid recall:\s?(\[[,\s\.\d]+\])'
    pat_valid_f1 = 'valid f1:\s?(\[[,\s\.\d]+\])'

    pat_net_name = re.compile(pat_net_name)
    pat_valid_loss = re.compile(pat_valid_loss)
    pat_valid_acc = re.compile(pat_valid_acc)
    pat_valid_auc = re.compile(pat_valid_auc)
    pat_valid_precis = re.compile(pat_valid_precis)
    pat_valid_recall = re.compile(pat_valid_recall)
    pat_valid_f1 = re.compile(pat_valid_f1)

    net_metrics = {}
    for i, line in enumerate(lines): 
        if "model has saved to" in line:
            net_name = pat_net_name.findall(line)[0]
            std_out_metrics = []
            metrics = lines[i-1]
            loss = pat_valid_loss.findall(metrics)[0]
            loss = eval(loss)
            acc = pat_valid_acc.findall(metrics)[0]
            acc = eval(acc)
            auc = pat_valid_auc.findall(metrics)[0]
            auc = eval(auc)
            precis = pat_valid_precis.findall(metrics)[0]
            precis = eval(precis)
            recall = pat_valid_recall.findall(metrics)[0]
            recall = eval(recall)
            f1 = pat_valid_f1.findall(metrics)[0]
            f1 = eval(f1)
            std_out_metrics.append(loss)
            std_out_metrics.append(acc[std_out_idx])
            std_out_metrics.append(auc[std_out_idx])
            std_out_metrics.append(precis[std_out_idx])
            std_out_metrics.append(recall[std_out_idx])
            std_out_metrics.append(f1[std_out_idx])
            net_metrics[net_name] = std_out_metrics
    
    net_score = {}
    # chkpt_list = glob.glob(os.path.join(chkpt_dir,'*.meta'))
    # chkpt_list.sort(key = lambda x: int(get_id(x)))
    for net_name in net_metrics:
        # net_name = os.path.basename(net_name)[:-5]
        net_score[net_name] = calculate_score(net_metrics[net_name], met_weights)
    
    # print(net_score)
    best_score = 0
    for net_name in net_score:
        if net_score[net_name] >= best_score:
            best_score = net_score[net_name]
            best_name = net_name

    best_model_file = os.path.join(chkpt_dir, best_name)
    return best_model_file


def calculate_score(metrics, met_weights):
    if met_weights is None:
        met_weights = [0, 0.7, 1, 0.9, 0.5, 0.7]
    score = 0
    for i, value in enumerate(metrics):
        score = score + met_weights[i] * value
    return score

def get_id(model_path):
    idx = re.findall('.*?(\d+).*?$', model_path)[0]
    return idx

if __name__=='__main__':
    
    # os.chdir('./multiloss_transformer')
    parse = argp.ArgumentParser(prog='analysis_log', usage='python analysis_log.py -p log_file -d chkpt_dir', description='choose best checkpoint according to the log file.', add_help=True)
    parse.add_argument('-p', '--log_file', default=None, type=str, help='The log file path.')
    parse.add_argument('-d', '--chkpt_dir', default=None, type=str, help='The dir that stores checkopints.')
    parse.add_argument('-i', '--std_out_idx', default=None, type=int, help='integer indicates which level is the output of the model.')
    parse.add_argument('-w', '--met_weights', default=None, type=list, help='a list contains 6 float indicates the weights for loss, acc, auc, pre, rec, f1.')
    args = parse.parse_args()
    log_file, chkpt_dir, std_out_idx, met_weights = update_params(args)
    best_model_file = choose_chkpt(log_file, chkpt_dir, std_out_idx, met_weights)
    # best_model_file="../checkpoint/20220329/yqg-intent-addpack-posandneg2random/no_both/best_model23"
    print(best_model_file)