import os
import warnings
warnings.filterwarnings("ignore")
import numpy as np
import modeling_seq_segment as modeling
import tensorflow as tf
import optimization 
import codecs
import evaluate 
import sklearn.metrics as metrics
import time
import logging

logger = None

def get_dense_out_res(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """get multi output from a FNN"""
    dense_tensor = in_tensor
    outs = []
    for i in range(loss_num):
        dense_tensor = tf.layers.dropout(
            dense_tensor, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor1 = tf.layers.dense(
            dense_tensor, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor1 = tf.layers.dropout(
            dense_tensor1, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor2 = tf.layers.dense(
            dense_tensor1, 
            hidden_size//4,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor2 = tf.layers.dropout(
            dense_tensor2, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor3 = tf.layers.dense(
            dense_tensor2, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor = dense_tensor3 + dense_tensor
        dense_tensor4 = tf.layers.dense(
        dense_tensor, 
        hidden_size//4,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        out_tensor = tf.layers.dense(
        dense_tensor4, 
        2,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        outs.append(out_tensor)
    return outs


def get_dense_out(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """get multi output from a FNN"""
    dense_tensor = in_tensor
    outs = []
    for i in range(loss_num):
        dense_tensor1 = tf.layers.dropout(
            dense_tensor, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor2 = tf.layers.dense(
            dense_tensor1, 
            hidden_size//4,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor = tf.layers.dense(
            dense_tensor2, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        out_tensor = tf.layers.dense(
        dense_tensor, 
        2,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        outs.append(out_tensor)
    return outs


def get_multitasks_out(in_tensor, hidden_size, loss_num, dropout_rate=0.5, is_training=True):
    """
    using multi tasks as decoder to get the predicted result
    """
    dense_tensor = in_tensor
    outs = []
    for i in range(loss_num):
        dense_tensor1 = tf.layers.dropout(
            in_tensor, 
            rate=dropout_rate,
            training=is_training
            )  # 0.5
        dense_tensor2 = tf.layers.dense(
            dense_tensor1, 
            hidden_size//4,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        dense_tensor3 = tf.layers.dense(
            dense_tensor2, 
            hidden_size,
            activation=modeling.gelu,
            kernel_initializer=modeling.create_initializer(0.02)
            )
        out_tensor = tf.layers.dense(
        dense_tensor3, 
        2,
        activation=modeling.gelu,
        kernel_initializer=modeling.create_initializer(0.02)
        )
        outs.append(out_tensor)
    return outs


def get_multi_layer_loss(labels, out_tensors, num_labels=5, loss_weights=None):
    """
    get multi loss when using multi output schema.
    """
    oh_labels = tf.one_hot(labels, num_labels+1)
    ones = tf.ones_like(oh_labels[:,0:2])
    zeros = tf.zeros_like(oh_labels[:,0:2])
    losses = []
    bias_ = 1
    for i in range(1, num_labels+1):
      # if i == 3:
      #   continue
      # if i > 3:
      #   bias_ = 2
      pos_col_ = tf.reduce_sum(oh_labels[:,i:], axis=-1, keep_dims=True)
      neg_col = tf.reduce_sum(oh_labels[:,0:i], axis=-1, keep_dims=True)
      bin_label = tf.concat([neg_col, pos_col_], axis=-1)
      # bin_label = tf.where(two_col>=i, ones, zeros, name='prop_label{}'.format(i))
      log_probs = tf.nn.log_softmax(out_tensors[i-bias_], axis=-1)
      per_example_loss = -tf.reduce_sum(bin_label * log_probs, axis=-1)
      loss = tf.reduce_mean(per_example_loss)
      losses.append(loss)
    out_loss = 0
    for i, ls in enumerate(losses):
        out_loss = out_loss + ls * loss_weights[i]
    return out_loss


def create_model(bert_config, is_training, input_ids, input_mask, segment_ids,
                 labels, num_labels, use_one_hot_embeddings):
  """Creates a classification model."""
  model = modeling.BertModel(
      config=bert_config,
      is_training=is_training,
      input_ids=input_ids,
      input_mask=input_mask,
      token_type_ids=segment_ids,
      use_one_hot_embeddings=use_one_hot_embeddings)

  # In the demo, we are doing a simple classification task on the entire
  # segment.
  #
  # If you want to use the token-level output, use model.get_sequence_output()
  # instead.
  output_layer = model.get_pooled_output()

  # one_hot_labels = tf.one_hot(labels, depth=num_labels, dtype=tf.float32)

  out_tensors = get_dense_out_res(output_layer, bert_config.hidden_size, bert_config.loss_num,bert_config.out_dense_drop, is_training)
  probabilities = []
  with tf.variable_scope("loss"):
      for ocnt, out_ts in enumerate(out_tensors):
        logits = out_ts
        prob = tf.nn.softmax(logits, axis=-1, name='Softmax_{}'.format(ocnt))
        probabilities.append(prob)
      out = tf.identity(probabilities[bert_config.std_out_idx], name='Softmax')  
  loss = get_multi_layer_loss(labels, out_tensors, num_labels, bert_config.loss_weights)
  return (loss, probabilities, model.sequence_output)


def convert_labels(labels, max_idx=5):
  '''
  convert 0,1,2,4,5 into special one-hot form 
  '''
  bs = labels.shape[0]
  true_labels = np.zeros([bs, max_idx+1])
  for i, lbl in enumerate(labels):
    if lbl == 0:
      true_labels[i, 0] = 1
      # true_labels[i, 1:] = 0
    else:
      true_labels[i, 1:lbl+1] = 1
  return true_labels


class ModelBuilder:
  def __init__(self, bert_config, num_labels, max_seq_length, init_checkpoint,
               learning_rate, num_train_steps, num_warmup_steps, use_tpu,
               use_one_hot_embeddings, nb_epoch, max_patience, check_freq,
               path_model):
    self._bert_config = bert_config
    self._num_labels = num_labels
    self._max_seq_length = max_seq_length
    self._init_checkpoint = init_checkpoint
    self._learning_rate = learning_rate
    self._num_train_steps = num_train_steps
    self._num_warmup_steps = num_warmup_steps
    self._use_tpu = use_tpu
    self._use_one_hot_embeddings = use_one_hot_embeddings
    self._nb_epoch = nb_epoch
    self._max_patience = max_patience
    self._check_freq = check_freq
    self._path_model = path_model

  def builde_model(self, mode='train'):
    self.input_ids_ph = tf.placeholder(
      tf.int32, shape=(None, self._max_seq_length), name='input_ids_ph')
    self.input_mask_ph = tf.placeholder(
      tf.int32, shape=(None, self._max_seq_length), name='input_mask_ph')
    self.segment_ids_ph = tf.placeholder(
      tf.int32, shape=(None, self._bert_config.max_type_length, self._max_seq_length), name='segment_ids_ph')
    self.label_ids_ph = tf.placeholder(tf.int32, shape=(None,), name='label_ph')
    self.is_training = tf.placeholder(tf.bool, name='is_training')


    (self.total_loss, self.probabilities, self.debug_output) = \
      create_model(
        self._bert_config, self.is_training, self.input_ids_ph,
        self.input_mask_ph, self.segment_ids_ph, self.label_ids_ph,
        self._num_labels, self._use_one_hot_embeddings)

    self._topk_labels = []
    for prob in self.probabilities:
      _, k_idx = tf.nn.top_k(prob, k=1)
      self._topk_labels.append(k_idx)

    self.normal_loss = self.total_loss

    # # entropy loss
    # p_log = tf.log(self.probabilities + 1e-8)
    # entropy = tf.reduce_mean(
    #   tf.reduce_sum(-self.probabilities * p_log, axis=-1), axis=-1)
    # beta = 0.01
    # self.total_loss -= beta * entropy

    tvars = tf.trainable_variables()

    scaffold_fn = None
    initialized_variable_names = None
    if self._init_checkpoint:
      logger.info('init model from {0}'.format(self._init_checkpoint))
      (assignment_map, initialized_variable_names
      ) = modeling.get_assignment_map_from_checkpoint(
        tvars, self._init_checkpoint)

      tf.train.init_from_checkpoint(self._init_checkpoint, assignment_map)

    logger.info("**** Trainable Variables ****")
    for var in tvars:
      init_string = ""
      if self._init_checkpoint and var.name in initialized_variable_names:
        init_string = ", *INIT_FROM_CKPT*"
      logger.info("  name = %s, shape = %s%s", var.name, var.shape,
                      init_string)

    if mode == 'train':
      self.train_op = optimization.create_optimizer(
        self.total_loss, self._learning_rate, self._num_train_steps,
        self._num_warmup_steps, self._use_tpu)
      # self.train_op = optimization.create_optimizer(
      #   self.total_loss, self._learning_rate)

    gpu_options = tf.GPUOptions(allow_growth=True)
    self._sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
    init = tf.global_variables_initializer()
    self._sess.run(init)

    self._model_saver = tf.train.Saver(max_to_keep=self._bert_config.max_save)
    if mode != 'train':
      self._restore_model()

  def _restore_model(self):
    self._model_saver.restore(self._sess, self._path_model)

  def _save_model(self, dev_loss, best_dev_loss, current_patience,num_model):
    """保存模型
    Args:
      dev loss: float
      best_dev_loss: float
      current_patience: int

    Returns:
      finished: boolean
      best_dev_loss: float
      current_patience: int
    """
    finished = False
    # save model
    if dev_loss < best_dev_loss:
      current_patience = 0
      best_dev_loss = 1.e8 
      # save model
      self._model_saver.save(self._sess, self._path_model+str(num_model))
      logger.info('model has saved to {0}!'.format(self._path_model+str(num_model)))
      finished = False
    else:
      current_patience += 1
      logger.info('no improvement, current patience: {0} / {1}'.format(
        current_patience, self._max_patience))
      if current_patience >= self._max_patience:
        logger.info(
          'finished training! (early stopping, max patience: {0})'.format(
            self._max_patience))
        finished = True

    return finished, best_dev_loss, current_patience

  def _save_model_acc(self, dev_acc, best_dev_acc, current_patience):
    """保存模型(根据dev acc)
    Args:
      dev acc: float
      best_dev_acc float
      current_patience: int

    Returns:
      finished: boolean
      best_dev_loss: float
      current_patience: int
    """
    finished = False
    # save model
    if dev_acc > best_dev_acc:
      current_patience = 0
      best_dev_acc = dev_acc
      # save model
      self._model_saver.save(self._sess, self._path_model)
      logger.info('model has saved to {0}!'.format(self._path_model))
      finished = False
    else:
      current_patience += 1
      logger.info('no improvement, current patience: {0} / {1}'.format(
        current_patience, self._max_patience))
      if current_patience >= self._max_patience:
        logger.info(
          'finished training! (early stopping, max patience: {0})'.format(
            self._max_patience))
        finished = True

    return finished, best_dev_acc, current_patience

  def get_feed_dict(self, inputs, is_training=True):
    feed_dict = {}
    input_ids, input_mask, segment_ids, label_ids = inputs[:]
    feed_dict[self.input_ids_ph] = input_ids
    feed_dict[self.input_mask_ph] = input_mask
    feed_dict[self.segment_ids_ph] = segment_ids
    feed_dict[self.label_ids_ph] = label_ids
    feed_dict[self.is_training] = is_training
    return feed_dict

  def train(self, data_iter_train, data_iter_valid):
    best_dev_loss = 1.e8
    best_dev_acc = -1
    current_patience = 0
    batch_count, instance_count = 0, 0
    train_loss = 0.
    log_writer = codecs.open(
      './log/acc_loss.txt', 'w', encoding='utf-8')
    num_model = 0
    for epoch in range(int(self._nb_epoch)):
      logger.info('epoch {0} / {1} / {2}'.format(epoch+1, self._nb_epoch,time.asctime(time.localtime(time.time()))))
      # train
      for i, inputs in enumerate(data_iter_train):
        feed_dict = self.get_feed_dict(inputs, is_training=True)
        loss, _ = self._sess.run(
          [self.total_loss, self.train_op], feed_dict=feed_dict)
        train_loss += loss
        batch_count += 1
        instance_count += inputs[0].shape[0]

        if batch_count % self._check_freq != 0:
          continue

        train_loss /= self._check_freq

        logger.info('batch_count: {0}, instance count: {1}'.format(
          batch_count, instance_count))
        # print('loss', train_loss)

        # evaluate
        dev_loss, dev_loss = 0., 0.
        label_ids_test, label_ids_gold = [], []
        label_ids_prob, label_ids_test, dev_acc, auc_num, precis, recall, f1_score = [], [], [], [], [], [], []
        prob_num = len(self.probabilities)
        for prob_cnt in range(prob_num):
          label_ids_prob.append([])
          label_ids_test.append([])
          dev_acc.append([])
          auc_num.append([])
          precis.append([])
          recall.append([])
          f1_score.append([])
        for i, inputs in enumerate(data_iter_valid):
          feed_dict = self.get_feed_dict(inputs, is_training=False)
          out_ts = [self.normal_loss]
          out_ts.extend(self.probabilities)
          loss_probs = self._sess.run(
            out_ts, feed_dict=feed_dict)
          loss = loss_probs[0]
          for prob_cnt, probabilities in enumerate(loss_probs[1:]):
            label_ids_prob[prob_cnt].append(probabilities[:,1])
            # label_ids_test[prob_cnt].append(np.argmax(probabilities, axis=-1))
          label_ids_gold.append(inputs[-1])
          dev_loss += loss
        dev_loss /= data_iter_valid.batch_count
        label_ids_gold = np.concatenate(label_ids_gold)
        label_ids_gold = convert_labels(label_ids_gold, self._bert_config.loss_num)
        bias = 1
        for prob_cnt in range(prob_num):
          # label_ids_test[prob_cnt] = np.concatenate(label_ids_test[prob_cnt])
          label_ids_prob[prob_cnt] = np.concatenate(label_ids_prob[prob_cnt])
          label_ids_test[prob_cnt] = label_ids_prob[prob_cnt] > evaluate.THRESHOLD
          if sum(label_ids_gold[:,prob_cnt+bias]) == 0:
            auc_num[prob_cnt] = 0.0
          else:
            auc_num[prob_cnt] = metrics.roc_auc_score(label_ids_gold[:,prob_cnt+bias], label_ids_prob[prob_cnt])
          precis[prob_cnt] = metrics.precision_score(label_ids_gold[:,prob_cnt+bias],label_ids_test[prob_cnt])
          recall[prob_cnt] = metrics.recall_score(label_ids_gold[:,prob_cnt+bias],label_ids_test[prob_cnt])
          f1_score[prob_cnt] = metrics.f1_score(label_ids_gold[:,prob_cnt+bias],label_ids_test[prob_cnt])

          # accuracy = metrics.accuracy_score(label_ids_gold,label_ids_test, average='weighted', labels=np.unique(label_ids_test))
          # compute acc
          dev_acc[prob_cnt] = sum((label_ids_gold[:,prob_cnt+bias]==label_ids_test[prob_cnt]).astype(np.int32)) \
                / label_ids_gold[:,prob_cnt+bias].shape[0]

        log_writer.write('{0}\t{1}\n'.format(dev_acc, dev_loss))

        logger.info(
          'train loss: {0}, valid loss: {1}, valid acc: {2}, valid auc: {3}, valid precis: {4}, valid recall:{5}, valid f1:{6}'.format(
          train_loss, dev_loss, dev_acc, auc_num,precis,recall,f1_score))

        train_loss = 0.

        # save model
        if batch_count % self._bert_config.save_freq != 0:
          continue
        finished, best_dev_loss, current_patience = self._save_model(
          dev_loss, best_dev_loss, current_patience,num_model)
        # finished, best_dev_acc, current_patience = self._save_model_acc(
        #   dev_acc, best_dev_acc, current_patience)
        num_model += 1
        if finished:
          return

    logger.info('finished training!')

  def predict(self, data_iter, result_file):
    instance_count = 0
    label_ids = []
    label_ids_test, label_ids_gold = [], []
    probability_list = []
    out_ts = []
    out_ts.extend(self.probabilities)
    out_ts.extend(self._topk_labels)
    out_ts.append(self.debug_output)
    probabilities = []
    prob_num = self._bert_config.loss_num
    test_acc = []
    test_acc_topk = []
    for prob_cnt in range(prob_num):
      probabilities.append([])
      label_ids_test.append([])
      probability_list.append([])
      test_acc.append([])
      test_acc_topk.append([])
    for i, inputs in enumerate(data_iter):
      feed_dict = self.get_feed_dict(inputs, is_training=False)
      out_var = self._sess.run(
        out_ts, feed_dict=feed_dict)
      # debug_output = out_var[-1]
      probabilities, topk_label_ids = out_var[0:prob_num], out_var[prob_num:-1]
      label_ids = inputs[-1]
      for prob_cnt in range(prob_num):
        # label_ids_test[prob_cnt].append(np.argmax(probabilities[prob_cnt], axis=-1))
        probability_list[prob_cnt].append(probabilities[prob_cnt][:,-1])
      label_ids_gold.append(inputs[-1])
      instance_count += inputs[0].shape[0]
    label_ids_gold = np.concatenate(label_ids_gold)
    label_ids_gold = convert_labels(label_ids_gold, self._bert_config.loss_num)
    bias = 1
    for prob_cnt in range(prob_num):
      probability_list[prob_cnt] = np.concatenate(probability_list[prob_cnt], axis=0)
      # label_ids_test[prob_cnt] = np.concatenate(label_ids_test[prob_cnt])
      label_ids_test[prob_cnt] = probability_list[prob_cnt] > evaluate.THRESHOLD

      test_acc[prob_cnt] = sum((label_ids_gold[:,prob_cnt+bias] == label_ids_test[prob_cnt]).astype(np.int32)) \
                / label_ids_gold.shape[0]
      # test_acc_topk[prob_cnt] = top_k_right_count[prob_cnt] / label_ids_gold[:,prob_cnt+bias].shape[0]
    logger.info('instance_count: {0}, acc: {1}'.format(
      instance_count, test_acc)) # , top-3 acc: {2} , test_acc_topk
    logger.info('finished!')

    # probability
    probability_list_all = np.concatenate(probability_list, axis=-1)
    path_test_result = os.path.join(result_file, 'test.prob.result')
    w_f = open(path_test_result,'w',encoding='utf-8')
    w_f.close()
    np.savetxt(path_test_result, probability_list_all)
    logger.info('result has wrote into: {0}'.format(path_test_result))
    return label_ids_test, probability_list # , predict_label_ids_topk

  @property
  def count_param(self):
    '''
    count the number of parameters of transformer
    '''
    # define three kinds of parameters
    Total_params = 0
    Trainable_params = 0
    NonTrainable_params = 0

    # access all variable returned from tf.global_variables() 
    for var in tf.global_variables():
        shape = var.shape # obtain the shape of each variable, its type is 'tensorflow.python.framework.tensor_shape.TensorShape'
        array = np.asarray([dim.value for dim in shape]) # convert into numpy array
        mulValue = np.prod(array) 

        Total_params += mulValue 
        if var.trainable:
            Trainable_params += mulValue 
        else:
            NonTrainable_params += mulValue 

    logger.info('Total params: {}'.format(Total_params))
    logger.info('Trainable params: {}'.format(Trainable_params))
    logger.info('Non-trainable params: {}'.format(NonTrainable_params))
    return Total_params, Trainable_params, NonTrainable_params

