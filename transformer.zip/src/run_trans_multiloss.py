#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""BERT finetuning runner."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import numpy as np
import json
import warnings
warnings.filterwarnings("ignore")
import modeling_seq_segment as modeling
# import modeling as modeling
import tokenization
import tensorflow as tf
from sklearn import metrics
import sys
sys.path.append('../data_analysis/')
import dataprovider as DataProv
import dataconstructor as DataCons
import evaluate
import transformer_builder as TransBuilder
import argparse as argp
import analysis_log as alog
import logging
import re 
import shutil


flags = tf.flags
FLAGS = flags.FLAGS

flags.DEFINE_string(
    "train_data_file", None,
    "The input training data file.")
flags.DEFINE_string(
    "test_data_file", None,
    "The input tests data file")
flags.DEFINE_string(
    "eval_data_file", None,
    "The input tests data file")
flags.DEFINE_string(
    "output_dir", None,
    "The output dir to store output model checkpoint file")
flags.DEFINE_string(
    "result_file", None,
    "The result dir to store output score file")
flags.DEFINE_bool("do_train", None, "Whether to run training.")
flags.DEFINE_bool("do_eval", None, "Whether to run eval on the dev set.")
flags.DEFINE_bool(
  "do_predict", None,
  "Whether to run the model in inference mode on the test set.")
flags.DEFINE_string(
  "vocab_file", None,
  "The vocabulary file that the BERT model was trained on.")
flags.DEFINE_string(
    "bert_config_file",
    None,
    "The config json file corresponding to the pre-trained BERT model. "
    "This specifies the model architecture.")
flags.DEFINE_integer(
    "max_seq_length", None,
    "The maximum total input sequence length after WordPiece tokenization. "
    "Sequences longer than this will be truncated, and sequences shorter "
    "than this will be padded.")
flags.DEFINE_integer(
    "max_type_length", None,
    "The maximum length of segment ids for each input feature . "
    "Sequences longer than this will be truncated, and sequences shorter "
    "than this will be padded.")
flags.DEFINE_string("main_feature", None, "Note use app or package for main feature.")
flags.DEFINE_list("loss_weights", None, "Note use app or package for main feature.")
flags.DEFINE_integer("std_out_idx", None, "Note use app or package for main feature.")

flags.DEFINE_bool(
    "init_chkpt",
    None,
    "Initial checkpoint (usually from a pre-trained BERT model).")
flags.DEFINE_string("load_model", None, "Choose the specific model to load.")
flags.DEFINE_integer("train_batch_size", None, "Total batch size for training.")
flags.DEFINE_integer("eval_batch_size", None, "Total batch size for eval.")
flags.DEFINE_integer("predict_batch_size", None, "Total batch size for predict.")
flags.DEFINE_float("learning_rate", None, "The initial learning rate for Adam.")
flags.DEFINE_float("num_train_epochs", None,
                   "Total number of training epochs to perform.")
flags.DEFINE_integer("check_freq", None, "check frequency")
flags.DEFINE_integer("save_freq", None,
                     "How often to save the model checkpoint.")
flags.DEFINE_integer("max_save", None,
                     "Max number to save the lastest model checkpoint.")
flags.DEFINE_float("threshold", None,
                     "Threshold when evaluate precision and recall save.")
flags.DEFINE_float(
    "warmup_proportion", None,
    "Proportion of training to perform linear learning rate warmup for. "
    "E.g., 0.1 = 10% of training.")
flags.DEFINE_bool("use_tpu", None, "Whether to use TPU or GPU/CPU.")
flags.DEFINE_string("gpu_id", None, "Note use app or package for main feature.")
flags.DEFINE_string("log_file", None, "Note use app or package for main feature.")
flags.DEFINE_list("metric_weights", None, "Note use app or package for main feature.")
flags.DEFINE_string("cate_dict", None, "Note use app or package for main feature.")


def load_config(train_cfg_file='./configs/train_transformer.json'):
    '''
    load training config file and inference
    '''
    cfg_fp = open(train_cfg_file)
    train_config = json.load(cfg_fp)
    cfg_fp.close()
    if train_config['main_feature'] == 'app':
        import app2_360cate as a2c 
        cate_dict = a2c.load_simple_cate_table('./configs/app_cate_ids.txt')
        train_config['cate_size'] = 1626
    elif train_config['main_feature'] == 'pack':
        import pack2gtcate as p2c
        cate_dict = p2c.load_simple_cate_table('./configs/package_cate_ids.txt')
        train_config['cate_size'] = 232
    train_config['cate_dict'] = cate_dict
    return train_config


def vocab_row_num(vocab_file):
    '''
    access the input file, return the line number + 1 
    '''
    fp = open(vocab_file)
    lines = fp.readlines()
    fp.close()
    return len(lines)


def update_config(train_config, bert_config):
    '''
    combine the config from input argment train config file and bert_config file
    '''
    for key in train_config:
        if hasattr(FLAGS, key) and (getattr(FLAGS, key) == None):
            setattr(FLAGS, key, train_config[key])
        elif hasattr(FLAGS, key):
            train_config[key] = getattr(FLAGS, key)
    cate_dict = train_config['cate_dict']
    if train_config['main_feature'] == 'pack':
        train_config['cate_dict'] = './configs/package_cate_ids.txt'
    elif train_config['main_feature'] == 'app':
        train_config['cate_dict'] = './configs/app_cate_ids.txt'
    train_cfg_str = json.dumps(train_config, indent=4, ensure_ascii=False)
    cfg_fp = open('./configs/train_transformer.json', mode='w', encoding='utf8')
    cfg_fp.writelines(train_cfg_str)
    cfg_fp.close()

    # update bert_config
    bert_config.max_seq_length = FLAGS.max_seq_length
    bert_config.max_type_length = FLAGS.max_type_length
    bert_config.std_out_idx = FLAGS.std_out_idx
    bert_config.loss_weights = FLAGS.loss_weights
    bert_config.vocab_size = vocab_row_num(FLAGS.vocab_file)
    bert_config.type_vocab_size = train_config['cate_size']
    bert_config.loss_num = len(FLAGS.loss_weights)
    bert_config.max_save = FLAGS.max_save
    bert_config.check_freq = FLAGS.check_freq
    bert_config.save_freq = FLAGS.save_freq
    bert_config.threshold = FLAGS.threshold

    # other setting
    evaluate.THRESHOLD = FLAGS.threshold
    os.environ["CUDA_VISIBLE_DEVICES"] = str(FLAGS.gpu_id)
    if FLAGS.do_predict and FLAGS.load_model is None and FLAGS.load_model==0:
        auto_load_model = alog.choose_chkpt(train_config['log_file'])
        train_config['load_model'] = auto_load_model
        FLAGS.load_model = auto_load_model
    elif FLAGS.do_train:
        FLAGS.load_model = os.path.join(FLAGS.output_dir, 'best_model')



def check_config(bert_config):
    '''
    check the configs is available or not and inference.
    notice that bert_config is a object, while the train_config is a dict instance
    '''
    if not FLAGS.do_train and not FLAGS.do_eval and FLAGS.do_predict:
        raise ValueError(
        "At least one of `do_train`, `do_eval` or `do_predict' must be True.")
    if FLAGS.max_seq_length > bert_config.max_position_embeddings:
        raise ValueError(
        "Cannot use sequence length %d because the BERT model "
        "was only trained up to sequence length %d" %
        (FLAGS.max_seq_length, bert_config.max_position_embeddings))


def main(_):

    # os.chdir('./multiloss_transformer')
    train_config = load_config()
    FLAGS.bert_config_file = FLAGS.bert_config_file or train_config['bert_config_file']
    bert_config = modeling.BertConfig.from_json_file(FLAGS.bert_config_file)
    update_config(train_config, bert_config)
    check_config(bert_config)
    logger = logging.getLogger('multiloss_transformer')
    logger.setLevel(logging.INFO)
    log_formatter = logging.Formatter(fmt="%(asctime)s - %(levelname)-4s - %(filename)-4s- %(message)s")
    term_hand = logging.StreamHandler()
    file_hand = logging.FileHandler(FLAGS.log_file, mode='w')
    term_hand.setLevel(logging.INFO)
    file_hand.setLevel(logging.INFO)
    term_hand.setFormatter(log_formatter)
    file_hand.setFormatter(log_formatter)
    logger.addHandler(term_hand)
    logger.addHandler(file_hand)
    TransBuilder.logger = logger
    DataCons.logger = logger
    logger.info('checking config')

    # here, the three config files will get some necessary parameters from each other

    tf.gfile.MakeDirs(FLAGS.output_dir)
    tf.gfile.MakeDirs(os.path.dirname(FLAGS.result_file))

    processor = DataCons.CallProcessor()
    label_list = processor.get_labels()

    tokenizer = tokenization.FullTokenizer(
        vocab_file=FLAGS.vocab_file, do_lower_case=True)
    train_examples = None
    eval_examples = None
    num_train_steps = None
    num_warmup_steps = None
    if FLAGS.do_train:
        train_examples = processor.get_train_examples(FLAGS.train_data_file)
        num_train_steps = int(
            len(train_examples) / FLAGS.train_batch_size * FLAGS.num_train_epochs)
        num_warmup_steps = int(num_train_steps * FLAGS.warmup_proportion)
        eval_examples = processor.get_dev_examples(FLAGS.eval_data_file)

    logger.info('building transformer')
    model_helper = TransBuilder.ModelBuilder(
        bert_config=bert_config,
        num_labels=bert_config.loss_num,
        init_checkpoint=FLAGS.init_chkpt,
        learning_rate=FLAGS.learning_rate,
        num_train_steps=num_train_steps,
        num_warmup_steps=num_warmup_steps,
        use_tpu=FLAGS.use_tpu,
        use_one_hot_embeddings=FLAGS.use_tpu,
        max_seq_length=FLAGS.max_seq_length,
        nb_epoch=FLAGS.num_train_epochs,
        path_model=FLAGS.load_model,
        check_freq=FLAGS.check_freq, max_patience=1000)

    if FLAGS.do_train:
        # copy the resources 
        shutil.copy(FLAGS.vocab_file, FLAGS.output_dir)
        shutil.copy(train_config['cate_dict'], FLAGS.output_dir)
        # train dataset
        train_input_ids, train_input_mask, train_segment_ids, train_label_ids = \
        DataCons.convert_examples_to_features(
            train_examples, label_list, FLAGS.max_seq_length, 
            FLAGS.max_type_length, FLAGS.cate_dict, tokenizer)
        data_iter_train = DataProv.DataIter(
        (train_input_ids, train_input_mask, train_segment_ids, train_label_ids),
        batch_size=FLAGS.train_batch_size, seed=1337)
        # valid dataset
        dev_input_ids, dev_input_mask, dev_segment_ids, dev_ids = \
        DataCons.convert_examples_to_features(
            eval_examples, label_list, FLAGS.max_seq_length, 
            FLAGS.max_type_length, FLAGS.cate_dict, tokenizer)
        data_iter_valid = DataProv.DataIter(
        (dev_input_ids, dev_input_mask, dev_segment_ids, dev_ids),
        batch_size=FLAGS.eval_batch_size, seed=1337)
        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(train_examples))
        logger.info("  Batch size = %d", FLAGS.train_batch_size)
        logger.info("  Num steps = %d", num_train_steps)
        # train
        model_helper.builde_model(mode='train')
        print(model_helper.count_param)

        model_helper.train(data_iter_train, data_iter_valid)


    if FLAGS.do_predict:
        if not FLAGS.do_train:
            model_helper.builde_model(mode='test')
            print(model_helper.count_param)

        predict_examples = processor.get_test_examples(FLAGS.test_data_file)
        test_input_ids, test_input_mask, test_segment_ids, test_ids = \
        DataCons.convert_examples_to_features(
            predict_examples, label_list, FLAGS.max_seq_length, 
            FLAGS.max_type_length, FLAGS.cate_dict, tokenizer)
        data_iter_test = DataProv.DataIter(
        (test_input_ids, test_input_mask, test_segment_ids, test_ids),
        batch_size=FLAGS.predict_batch_size)

        logger.info("***** Running prediction*****")
        logger.info("  Num examples = %d", len(predict_examples))
        logger.info("  Batch size = %d", FLAGS.predict_batch_size)
        # (test_count, nb_classes) , predict_label_ids_topk
        test_label_ids, probabilities = \
        model_helper.predict(data_iter_test)

        # prob_file = FLAGS.result_dir + 'test.prob.result'
        # evaluate.run_evaluate(prob_file, None, test_label_ids, FLAGS.result_dir+'evaluate.{}.{}.txt'.format(load_model, evaluate.THRESHOLD))
        for prob_cnt in range(len(test_label_ids)):
            label_ids_test = test_label_ids[prob_cnt]
            label_ids_prob = probabilities[prob_cnt]
            label_ids_gold = TransBuilder.convert_labels(test_ids, bert_config.loss_num)
            auc_num = metrics.roc_auc_score(label_ids_gold, label_ids_prob)
            precis = metrics.precision_score(label_ids_gold,label_ids_test)
            recall = metrics.recall_score(label_ids_gold,label_ids_test)
            f1_score = metrics.f1_score(label_ids_gold,label_ids_test)
            logger.info("report_loss_{}: auc={}, pre={}, recall={}, f1={}".format(prob_cnt, auc_num, precis, recall, f1_score))
        # predict_file = os.path.join(FLAGS.result_dir, "test_results_{}.txt".format(prob_cnt))
        # with codecs.open(predict_file, 'w', encoding='utf-8') as file_result:
        #   for label_id in test_label_ids[prob_cnt]:
        #     file_result.write('{0}\n'.format(label_list[label_id]))

        # data_count = probabilities[prob_cnt].shape[0]
        # predict_file = os.path.join(FLAGS.result_dir, "test_results_{}.prob.txt".format(prob_cnt))
        # with codecs.open(predict_file, 'w', encoding='utf-8') as file_result:
        #   for i in range(data_count):
        #     label_ids = np.argsort(probabilities[prob_cnt][i]).reshape(-1)[::-1]
        #     temp = []
        #     for idx in label_ids:
        #       temp.append(DataCons.CallProcessor.get_labels()[idx])
        #     file_result.write('{0}\n'.format(' '.join(temp[:3])))


if __name__ == "__main__":

    # os.chdir('./multiloss_transformer')
    tf.app.run()
