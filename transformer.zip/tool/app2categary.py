#!/use/bin/env/ python3
# -*- encoding: UTF-8 -*-

# 根据 app 名称 生成 dict : 'app name': [一级标签，[二级标签]]

# import csv
import codecs

rough_cate_path1 = '../data_analysis/讯飞标签.txt'
fine_cate_path2 = '../data_analysis/爬虫标签.txt'


def load_rough_cate_table(pri_save_path='./train_cate1.txt', sec_save_path='./train_cate2.txt'):
    '''
    load 粗略的一级、二级标签
    '''
    app_list = dict()
    pri_lbl = set()
    sec_lbl = set()
    fp = codecs.open(rough_cate_path1, mode='r', encoding='utf-8')
    # fp = open(rough_cate_path1, mode='r', encoding='utf-8')
    lines = fp.readlines()
    fp.close()
    for i, line in enumerate(lines):
        if i==0:
            continue
        app_name, second_id, second_label, primary_label = line.strip().split('\t')
        if app_name in app_list:
            print('warning: repeated app name: {} !'.format(app_name))
        else:
            app_list[app_name] = [primary_label, [second_label]]
        pri_lbl.add(primary_label)
        sec_lbl.add(second_label)
    pri_lbl = list(pri_lbl)
    pri_lbl.sort()
    sec_lbl = list(sec_lbl)
    sec_lbl.sort()
    if pri_save_path:
        fp = codecs.open(pri_save_path, mode='w', encoding='utf-8')
        for line in pri_lbl:
            fp.write(line+'\n')
        fp.close()
    if sec_save_path:
        fp = codecs.open(sec_save_path, mode='w', encoding='utf-8')
        for line in sec_lbl:
            fp.write(line+'\n')
        fp.close()
    return app_list, pri_lbl, sec_lbl


def load_fine_cate_table(app_list, s2p_map=None):
    '''
    load 精细的二级标签列表
    '''
    fp = codecs.open(rough_cate_path1, mode='r', encoding='utf8')
    lines = fp.readlines()
    fp.close()
    for i, line in enumerate(lines):
        if i==0:
            continue
        series_num, app_name, second_labels, corporation = line.strip().split('\t')
        second_labels = second_labels.strip().split(' ')
        if app_name in app_list:
            app_list[app_name][1].extend(second_labels)
        else:
            print('warning: no app name in dict: {} !'.format(app_name))
            # 可以考虑使用 word2vec 为无次级标签的 app 补充相似 app 的标签
            # 当前选择直接方案：一级标签置空，然后通过二级标签揣测一级标签
            app_list[app_name] = ['null', second_labels]
    
    # 若一级标签缺失，尝试用二级标签去揣测一级标签
    if s2p_map:
        for app_name in app_list:
            if app_list[app_name][0] == 'null':
                pass
    return app_list


def get_pri_sec_map(app_list):
    '''
    根据部分app的一二级标签的关系，建立映射表
    '''
    pri2sec = dict()
    for app_name in app_list:
        app_label = app_list[app_name]
        if app_label[0] not in pri2sec:
            pri2sec[app_label[0]] = set()
        pri2sec[app_label[0]] = pri2sec[app_label[0]].union(app_label[1])
        
    sec2pri = dict()
    for pri in pri2sec:
        sec_list = pri2sec[pri]
        for sec in sec_list:
            if sec not in sec2pri:
                sec2pri[sec] = set()
            sec2pri[sec].add(pri)
    return pri2sec, sec2pri


def sec2pri(app_list, pri_lbl, sec_lbl):
    '''
    二级标签到一级标签的映射表
    '''
    sec2pri_table = dict()
    for app in app_list:
        pri, secs = app_list[app]
        sec = secs[0]
        if sec not in sec2pri_table:
            sec2pri_table[sec] = []
        sec2pri_table[sec].append(pri)
    for sec in sec2pri_table:
        sec2pri_table[sec] = list(set(sec2pri_table[sec]))
    return sec2pri_table


def build_cate_vocab(sec2pri_table, save_path='./train_cate.txt'):
    combine_lbl = []
    for sec in sec2pri_table:
        for pri in sec2pri_table[sec]:
            combine_lbl.append('{}>{}'.format(pri, sec))
    combine_lbl.sort()
    if save_path:
        fp = codecs.open(save_path, mode='w', encoding='utf-8')
        for line in combine_lbl:
            fp.write(line+'\n')
        fp.close()
    return combine_lbl


if __name__ == '__main__':

    app_list, pri_lbl, sec_lbl = load_rough_cate_table()
    sec2pri_table = sec2pri(app_list, pri_lbl, sec_lbl)
    combine_lbl = build_cate_vocab(sec2pri_table)
