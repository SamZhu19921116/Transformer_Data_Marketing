import onnx
from onnx import helper, checker
from onnx import TensorProto
import re
import argparse as argp

def createGraphMemberMap(graph_member_list):
    member_map=dict()
    for n in graph_member_list:
        print(n.op_type)
    return member_map

input_model = "/home/sdsong/zwhuang14/transformer/checkpoint/20220414/sb-multilabel/frozen_model.onnx"
output_model = "/home/sdsong/zwhuang14/transformer/checkpoint/20220414/sb-multilabel/frozen_model.onnx"

model = onnx.load(input_model)
graph = model.graph
print(graph.output[0].name)
for n in graph.node:
    if n.name == "loss/loss/Softmax":
        print(n.name)
        n.name = "loss/Softmax"
# onnx.save(model, output_model)
# model = onnx.load(output_model)
# graph = model.graph
for n in graph.node:
    if 'Softmax' in n.name:
        print(n)

# if __name__ == '__main__':
#     # cate_path = './data_analysis/package_cate_ids.txt'
#     parse = argp.ArgumentParser(prog='set_onnx_out', usage='python set_onnx_out.py -p cate_path -t pack_cate_path', description='map category of pack into ids according to the getui category table.', add_help=True)
#     parse.add_argument('-p', '--cate_path', required=True, type=str, help='The file, which contains pack and category mpacking.')
#     parse.add_argument('-t', '--pack_cate_path', required=True, type=str, help='where to save the simple idx map.')
#     args = parse.parse_args()
#     cate_path, pack_cate_path = args.cate_path, args.pack_cate_path
