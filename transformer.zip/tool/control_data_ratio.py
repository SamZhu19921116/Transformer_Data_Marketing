#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import os
base_path = '/home/sdsong/zwhuang14/transformer/'
data_set = 'data_zaxd/20211214/no_both'

train_vs_test_ratio = 3.0

source_dir = os.path.join(base_path, data_set)
target_dir = os.path.join(base_path, data_set+'_part_1vs3')

train_data_file_name = 'train_data'
test_data_file_name = 'test_data'

train_part_fp = open(os.path.join(target_dir, train_data_file_name), 'w', encoding='utf-8')

with open(os.path.join(source_dir, train_data_file_name), 'r', encoding='utf-8') as train_fp:
    pos_cases = []
    pos_num = 0
    while True:
        line = train_fp.readline()
        if line.startswith('pos'):
            pos_cases.append(line)
            # train_part_fp.write(line)
            pos_num = pos_num + 1
        elif line == '':
            break
print('INFO:--------pos_num: {}'.format(pos_num))
# exit()
with open(os.path.join(source_dir, train_data_file_name), 'r', encoding='utf-8') as train_fp:
    neg_cases = []
    neg_num =  pos_num * train_vs_test_ratio 
    while neg_num > 0:
        line = train_fp.readline()
        if line.startswith('neg'):
            neg_cases.append(line)
            # train_part_fp.write(line)
            neg_num = neg_num - 1
        elif line == '':
            break
print('INFO:--------neg_num: {}'.format(neg_num))

train_part = pos_cases
train_part.extend(neg_cases)
for i in range(pos_num+neg_num):
    train_part_fp.write(train_part[i])

train_part_fp.close()
