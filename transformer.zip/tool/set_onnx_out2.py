import onnx
 
onnx_model = onnx.load('/home/sdsong/zwhuang14/transformer/checkpoint/20220414/sb-multilabel/frozen_model.onnx')
 
endpoint_names = 'loss/loss/Softmax:0'
new_name = 'loss/Softmax:0'

for i in range(len(onnx_model.graph.node)):
	for j in range(len(onnx_model.graph.node[i].input)):
		if onnx_model.graph.node[i].input[j] == endpoint_names:
			print('-'*60)
			print(onnx_model.graph.node[i].name)
			print(onnx_model.graph.node[i].input)
			print(onnx_model.graph.node[i].output)
 
			onnx_model.graph.node[i].input[j] = new_name
 
	for j in range(len(onnx_model.graph.node[i].output)):
		if onnx_model.graph.node[i].output[j] == endpoint_names:
			print('-'*60)
			print(onnx_model.graph.node[i].name)
			print(onnx_model.graph.node[i].input)
			print(onnx_model.graph.node[i].output)
 
			onnx_model.graph.node[i].output[j] = new_name
 
for i in range(len(onnx_model.graph.input)):
	if onnx_model.graph.input[i].name == endpoint_names:
		print('-'*60)
		print(onnx_model.graph.input[i])
		onnx_model.graph.input[i].name = new_name
 
for i in range(len(onnx_model.graph.output)):
	if onnx_model.graph.output[i].name == endpoint_names:
		print('-'*60)
		print(onnx_model.graph.output[i])
		onnx_model.graph.output[i].name = new_name
 
onnx.save(onnx_model, '/home/sdsong/zwhuang14/transformer/checkpoint/20220414/sb-multilabel/frozen_model.onnx')
