#! /bin/bash

content=$(cat $1)
zero=0
for ((i=0;i<10;i=i+1))
do 
    if ((${i}==${zero})); then
        end='.*'
        else
        end='01'
    fi

    num=$(echo "$content" | grep ' ['${i}'-9]\..*e-'${end} | wc -l)
    echo 'number pass thres 0.'${i}' = '${num}
done
