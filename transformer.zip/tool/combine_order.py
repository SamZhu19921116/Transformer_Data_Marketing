#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import os 
import glob

def data_processer(line):
    items = line.strip().split('\t')
    ident = items[0]
    prob = items[1]
    gt_8 = 0
    if float(prob) < 0.5:
        is_jump = True
    else:
        is_jump = False
    if float(prob) > 0.8:
        gt_8 = 1
    return ident, prob, is_jump, gt_8


def csv2line_data_headict(data_path, encoding='utf-8', callback=None, kwargs={}):
    '''
    读 csv , 转换格式
    '''
    fp = open(data_path, 'r', encoding=encoding)
    lines = fp.readlines()
    if not callback:
        return lines
    ln_data_ = []
    gt_8_count = 0
    if callback:
        for ln in lines:
            kwargs['line'] = ln
            label, data, is_jump, gt_8 = callback(**kwargs)
            if is_jump:
              continue
            gt_8_count = gt_8_count + gt_8
            ln_data_.append((label, data))
    return ln_data_, gt_8_count


def write_user_prob(user_prob, file_name):
    '''
    把排好序的用户写到文件中
    '''
    with open(file_name, 'w+', encoding='utf-8') as fp:
        for usr in user_prob:
            fp.write(usr[0] + '\t' + usr[1] + '\n')


def sort_prob(user_prob):
    '''
    根据 prob 排序 user
    '''
    odered_user = sorted(user_prob, key=lambda x:float(x[1]), reverse=True)
    return odered_user


mode = 'predict'
data_ident = './data_zaxd/20220301/{}/'.format('no_both')
source_dir = './prediction/' + data_ident
prediction_path = source_dir + 'prediction_part-'
target_dir = './sorted/' + data_ident 
target_path = target_dir + 'user_prob.txt'

os.makedirs(target_dir, exist_ok=True)
prediction_file_list = glob.glob(prediction_path+'*')
users = []
for pred_file in prediction_file_list:
    file_name = os.path.basename(pred_file)
    part_data_lines, gt_8 = csv2line_data_headict(pred_file, callback=data_processer)
    print('gt_5 = {}'.format(len(part_data_lines)))
    print('gt_8 = {}'.format(gt_8))
    users.extend(part_data_lines)
    
users = sort_prob(users)
write_user_prob(users, target_path)


    
