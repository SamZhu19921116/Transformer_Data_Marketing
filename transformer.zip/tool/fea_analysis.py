#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

import os
import glob
import threading
import argparse as argp


# multi-threads
class MultiThread():
    def __init__(self, func, args):
        self.args = args
        self.num = len(args)
        if not isinstance(func, list):
            func = [func]
        if len(func) == 1:
            self.func = func*self.num

    def run(self):
        thr = []
        for i in range(self.num):
            cur_func = self.func[i]
            cur_args = self.args[i]
            t = threading.Thread(target=cur_func, args=cur_args)
            thr.append(t)
        [t.start() for t in thr]
        [t.join() for t in thr]
        print('INFO:-------------processing finished -------------')
        return 0


def main_func(in_file, out_fp, mode, func):
    if not func:
        print("no operation...")
        exit()
    with open(in_file, 'r', encoding='utf-8') as in_fp:
        lines = in_fp.readlines()
        for line in lines:
            # here is the processing func
            result = analyze_train(line, mode, func)
            out_fp.write(result)


def analyze_train(data_dir, mode="train", func=None):
    if not func:
        print("no operation...")
        exit()
    if mode == "train":
        data_dir = os.path.join(data_dir, 'traindata/')
        data_file_list = glob.glob(data_dir+'*.txt')
    elif mode == "test":
        data_dir = os.path.join(data_dir, 'testdata/')
        data_file_list = glob.glob(data_dir+'*.txt')
    

